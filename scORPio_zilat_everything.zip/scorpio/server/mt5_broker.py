"""
mt5_broker.py - MetaTrader 5 broker (works with Exness) for scORPio zilat.

Needs: Windows, the MT5 terminal installed from Exness and logged in, and `pip install MetaTrader5`.
In MT5: click "Algo Trading" ON, Tools > Options > Expert Advisors > tick "Allow algorithmic trading",
and Tools > Options > Charts > "Max bars in chart" = Unlimited (so 150 days of history can load).
Exness symbol names often carry a suffix (EURUSDm, EURUSDz...). Set JARVIS_MT5_SUFFIX, or let it auto-detect.
"""
import os, math, time
from datetime import datetime, timezone
import numpy as np

try:
    import MetaTrader5 as mt5
except ImportError:
    mt5 = None

OFFSET = int(float(os.environ.get("JARVIS_MT5_UTC_OFFSET_HOURS", "0")) * 3600)   # Exness servers run on UTC
SUFFIX = os.environ.get("JARVIS_MT5_SUFFIX", "")
MAGIC, COUNT = 5150921, 5000
STEP = {"M1": 60, "M5": 300, "H1": 3600}
PAIRS = ["EUR_USD", "GBP_USD", "USD_JPY", "AUD_USD", "NZD_USD", "USD_CAD", "USD_CHF", "XAU_USD"]
_sym_cache, _state = {}, {"ready": False}


def _init():
    if mt5 is None:
        raise RuntimeError("The MetaTrader5 package is missing. On Windows run: pip install MetaTrader5")
    if _state["ready"] and mt5.terminal_info() is not None:
        return
    kw = {}
    if os.environ.get("MT5_PATH"):
        kw["path"] = os.environ["MT5_PATH"]
    if os.environ.get("MT5_LOGIN"):
        kw.update(login=int(os.environ["MT5_LOGIN"]), password=os.environ.get("MT5_PASSWORD", ""),
                  server=os.environ.get("MT5_SERVER", ""))
    if not mt5.initialize(**kw):
        raise RuntimeError(f"Cannot reach the MT5 terminal ({mt5.last_error()}). Open MT5, log in to Exness, and try again.")
    _state["ready"] = True


def _tf(g):
    return getattr(mt5, "TIMEFRAME_" + g)


def _sym(inst):
    if inst in _sym_cache:
        return _sym_cache[inst]
    base = inst.replace("_", "")
    for cand in (base + SUFFIX, base):
        if mt5.symbol_select(cand, True):
            _sym_cache[inst] = cand
            return cand
    found = mt5.symbols_get(base + "*") or []
    if found:
        name = sorted((s.name for s in found), key=len)[0]
        mt5.symbol_select(name, True)
        _sym_cache[inst] = name
        return name
    raise RuntimeError(f"Symbol {base} not found in MT5 Market Watch. Set JARVIS_MT5_SUFFIX (for example m or z).")


def _pack(r):
    if r is None or len(r) == 0:
        e = np.array([])
        return dict(t=np.array([], dtype=np.int64), o=e, h=e, l=e, c=e)
    return dict(t=r["time"].astype(np.int64) - OFFSET, o=r["open"].astype(float), h=r["high"].astype(float),
                l=r["low"].astype(float), c=r["close"].astype(float))


class MT5:
    def __init__(self):
        _init()
        a = mt5.account_info()
        if a is None:
            raise RuntimeError("MT5 is not logged in to an account.")
        self.env = "live" if a.trade_mode == mt5.ACCOUNT_TRADE_MODE_REAL else "practice"
        if self.env == "live" and os.environ.get("JARVIS_ALLOW_LIVE") != "1":
            raise RuntimeError("This is a REAL Exness account and live trading is locked. Set JARVIS_ALLOW_LIVE=1 to unlock it.")
        self.acct = a.login

    def candles(self, inst):
        r = mt5.copy_rates_from_pos(_sym(inst), _tf("H1"), 0, COUNT + 1)
        if r is None or len(r) < 250:
            raise RuntimeError(f"Not enough H1 history for {inst}. Open its chart in MT5 and scroll back.")
        d = _pack(r)
        live = float(d["c"][-1])                                  # last bar is still forming
        return dict(o=d["o"][:-1], h=d["h"][:-1], l=d["l"][:-1], c=d["c"][:-1], t=[str(int(x)) for x in d["t"][:-1]]), live

    def bars_since(self, inst, start, gran="M1"):
        sym = _sym(inst)
        now_srv = mt5.symbol_info_tick(sym).time
        r = mt5.copy_rates_range(sym, _tf(gran), datetime.fromtimestamp(start + OFFSET, timezone.utc),
                                 datetime.fromtimestamp(now_srv + 86400, timezone.utc))
        d = _pack(r)
        keep = d["t"] + OFFSET + STEP[gran] <= now_srv           # drop the forming bar
        return {k: v[keep] for k, v in d.items()}

    def bars_history(self, inst, gran="M1", days=None):
        days = days or {"M1": 250, "M5": 365}.get(gran, 365)
        path = os.path.join(os.path.expanduser("~"), ".jarvis_cache", f"mt5_{inst}_{gran}.npz")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        now, old = int(time.time()), None
        if os.path.exists(path):
            z = np.load(path)
            old = {k: z[k] for k in "tohlc"}
        start = int(old["t"][-1]) + STEP[gran] if old is not None and len(old["t"]) else now - days * 86400
        new = self.bars_since(inst, start, gran)
        m = new if old is None else {k: np.concatenate([old[k], new[k]]) for k in "tohlc"}
        keep = m["t"] >= now - days * 86400
        m = {k: v[keep] for k, v in m.items()}
        np.savez(path, **m)
        return m

    def m1_since(self, inst, start):
        return self.bars_since(inst, start, "M1")

    def m1_history(self, inst, days=None):
        return self.bars_history(inst, "M1", days)

    def spread(self, inst):
        t = mt5.symbol_info_tick(_sym(inst))
        return float(t.ask - t.bid)

    def open_positions(self):
        rev = {}
        for i in PAIRS:
            try:
                rev[_sym(i)] = i
            except RuntimeError:
                pass
        out = []
        for p in mt5.positions_get() or []:
            if p.symbol in rev:
                out.append(dict(id=p.ticket, inst=rev[p.symbol], side=1 if p.type == mt5.POSITION_TYPE_BUY else -1,
                                units=p.volume * mt5.symbol_info(p.symbol).trade_contract_size, lots=p.volume,
                                entry=p.price_open, sl=p.sl or None, tp=p.tp or None, price=p.price_current,
                                pl=p.profit, ours=p.magic == MAGIC))
        return out

    def move_sl(self, pos, sl):
        sym = _sym(pos["inst"])
        res = mt5.order_send(dict(action=mt5.TRADE_ACTION_SLTP, position=pos["id"], symbol=sym,
                                  sl=round(sl, mt5.symbol_info(sym).digits), tp=pos["tp"] or 0.0))
        return res is not None and res.retcode == mt5.TRADE_RETCODE_DONE

    def close_position(self, pos):
        sym = _sym(pos["inst"])
        info, tick = mt5.symbol_info(sym), mt5.symbol_info_tick(sym)
        long = pos["side"] > 0
        fm = info.filling_mode
        fill = mt5.ORDER_FILLING_FOK if fm & 1 else mt5.ORDER_FILLING_IOC if fm & 2 else mt5.ORDER_FILLING_RETURN
        res = mt5.order_send(dict(action=mt5.TRADE_ACTION_DEAL, position=pos["id"], symbol=sym, volume=pos["lots"],
                                  type=mt5.ORDER_TYPE_SELL if long else mt5.ORDER_TYPE_BUY, price=tick.bid if long else tick.ask,
                                  deviation=20, magic=MAGIC, comment="scORPio close", type_time=mt5.ORDER_TIME_GTC, type_filling=fill))
        return res is not None and res.retcode == mt5.TRADE_RETCODE_DONE

    def closed_trades(self, since):
        """Closed trades opened by this app (magic number), with the strategy read from the opening deal's comment."""
        deals = mt5.history_deals_get(datetime.fromtimestamp(since + OFFSET, timezone.utc),
                                      datetime.fromtimestamp(time.time() + OFFSET + 86400, timezone.utc)) or []
        by = {}
        for d in deals:
            if d.magic != MAGIC:
                continue
            x = by.setdefault(d.position_id, dict(pl=0.0, strat="", t=0, inst=d.symbol, closed=False))
            x["pl"] += d.profit + d.commission + d.swap
            if d.entry == mt5.DEAL_ENTRY_IN:
                x["strat"] = d.comment[3:] if d.comment.startswith("sz:") else d.comment
            if d.entry == mt5.DEAL_ENTRY_OUT:
                x["closed"], x["t"] = True, d.time - OFFSET
        return [dict(id=str(k), inst=x["inst"], pl=x["pl"], t=x["t"], strat=x["strat"])
                for k, x in by.items() if x["closed"] and x["t"] >= since]

    def summary(self):
        a = mt5.account_info()
        return float(a.balance), a.currency, len(mt5.positions_get() or [])

    def equity(self):
        return float(mt5.account_info().equity)

    def open_instruments(self):
        have = {p.symbol for p in (mt5.positions_get() or [])}
        out = set()
        for i in PAIRS:
            try:
                if _sym(i) in have:
                    out.add(i)
            except RuntimeError:
                pass
        return out

    def order(self, inst, units, sl, tp, dec, strat=""):
        """Market order. Returns an OANDA-shaped dict so trader.execute() can read it."""
        sym = _sym(inst)
        info, tick = mt5.symbol_info(sym), mt5.symbol_info_tick(sym)
        buy = units > 0
        lots = abs(units) / info.trade_contract_size
        lots = round(min(math.floor(lots / info.volume_step + 1e-9) * info.volume_step, info.volume_max), 8)
        if lots < info.volume_min:                                # never round UP: that would exceed the risk limit
            return {"orderCancelTransaction": {"reason": f"size is below the broker minimum lot of {info.volume_min}"}}
        fm = info.filling_mode
        fill = mt5.ORDER_FILLING_FOK if fm & 1 else mt5.ORDER_FILLING_IOC if fm & 2 else mt5.ORDER_FILLING_RETURN
        req = dict(action=mt5.TRADE_ACTION_DEAL, symbol=sym, volume=lots,
                   type=mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL,
                   price=tick.ask if buy else tick.bid, sl=round(sl, info.digits), tp=round(tp, info.digits),
                   deviation=20, magic=MAGIC, comment=("sz:" + strat)[:31] if strat else "scORPio zilat", type_time=mt5.ORDER_TIME_GTC, type_filling=fill)
        res = mt5.order_send(req)
        if res is None:
            return {"orderCancelTransaction": {"reason": str(mt5.last_error())}}
        if res.retcode == mt5.TRADE_RETCODE_DONE:
            return {"orderFillTransaction": {"price": res.price or req["price"]}}
        return {"orderCancelTransaction": {"reason": f"retcode {res.retcode}: {res.comment}"}}
