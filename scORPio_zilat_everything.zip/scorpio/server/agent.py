"""
agent.py - the MANAGER of scORPio zilat's trading desk.

Jarvis is the boss: he understands what you want and gives the manager her orders.
The manager is handed everything Jarvis knows (the Playbook), does the work, learns from her real results, and reports back.
She can never raise the risk limits, get around the kill switch, or trade on autopilot unless Jarvis has authorised it.
"""
import os, re, csv, json, time, threading
import brain, trader

CACHE = os.path.join(os.path.expanduser("~"), ".jarvis_cache")
STATE = os.path.join(CACHE, "manager.json")
LOOP_SECONDS = 300


class Playbook:
    """Everything Jarvis knows, given to the manager: strategies, teaching topics and the hard rules."""
    EXTRA = {
        "9 AM CR model": "Mark the 8 AM one-hour range (New York). When the 9 AM hour sweeps one side, wait for an inverse "
                         "fair value gap plus an order block on the 1-minute chart, enter, stop beyond the swing, target the other side.",
        "4 Hour Range": "Mark the first 4-hour candle's range. When a 5-minute candle closes outside it and the next closes back "
                        "inside, fade the failed breakout: stop beyond the extreme, target the opposite side.",
    }

    def __init__(self):
        self.strategies = {n: (fn.__doc__ or "").strip() for n, (fn, _, _) in trader.STRATS.items()}
        self.strategies.update(self.EXTRA)
        self.knowledge = list(brain.FOREX_KB)

    def rules(self):
        return dict(risk_pct=trader.risk_pct(), max_open=trader.MAX_OPEN, max_trades_per_day=trader.MAX_TRADES_PER_DAY,
                    daily_loss_pct=trader.MAX_DAILY_LOSS_PCT, leverage=trader.MAX_LEVERAGE)

    def lookup(self, q):
        s = q.lower()
        for pat, ans in self.knowledge:
            if re.search(pat, s):
                return ans
        return None

    def summary(self):
        r = self.rules()
        return (f"Jarvis has taught me {len(self.strategies)} strategies ({', '.join(self.strategies)}), "
                f"{len(self.knowledge)} market topics, and my hard rules: risk {r['risk_pct']:g} percent per trade, at most "
                f"{r['max_open']} open trades and {r['max_trades_per_day']} trades a day, a {r['daily_loss_pct']:g} percent daily loss stop, "
                f"a drawdown halt at {Manager.HALT_DD:g} percent, the kill switch, session and news filters, a currency-exposure limit, "
                f"a spread check, and break-even stops once a trade is up one risk unit.")


class Ledger:
    """The manager's memory of real closed trades, saved to disk."""
    def __init__(self):
        try:
            self.d = json.load(open(STATE))
        except Exception:
            self.d = {}
        for k, v in (("trades", []), ("peak", {}), ("bench", {}), ("last", 0)):
            self.d.setdefault(k, v)

    def save(self):
        os.makedirs(os.path.dirname(STATE), exist_ok=True)
        json.dump(self.d, open(STATE, "w"))

    def add(self, t):
        if any(x["id"] == t["id"] for x in self.d["trades"]):
            return False
        self.d["trades"].append(t)
        self.d["last"] = max(self.d["last"], t["t"])
        self.save()
        return True

    def stats(self, strat=None):
        pl = [x["pl"] for x in self.d["trades"] if strat is None or x["strat"] == strat]
        if not pl:
            return dict(n=0, win=0.0, expectancy=0.0, pf=0.0, total=0.0)
        wins, losses = [p for p in pl if p > 0], [p for p in pl if p <= 0]
        return dict(n=len(pl), win=len(wins) / len(pl) * 100, expectancy=sum(pl) / len(pl),
                    pf=(sum(wins) / abs(sum(losses))) if losses and sum(losses) else (9.9 if wins else 0.0), total=sum(pl))

    def bench(self, strat, days):
        self.d["bench"][strat] = time.time() + days * 86400
        self.save()

    def benched(self):
        now = time.time()
        return {s for s, until in self.d["bench"].items() if until > now}

    def peak(self, acct, eq):
        p = max(self.d["peak"].get(acct, 0), eq)
        if p != self.d["peak"].get(acct):
            self.d["peak"][acct] = p
            self.save()
        return p

    def export(self, path):
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["closed_at_utc", "instrument", "strategy", "profit"])
            for x in sorted(self.d["trades"], key=lambda x: x["t"]):
                w.writerow([time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(x["t"])), x["inst"], x["strat"], f"{x['pl']:.2f}"])
        return len(self.d["trades"])

    def reset_peak(self, acct, eq):
        self.d["peak"][acct] = eq
        self.save()


MAX_WORKERS_HARD = 8      # a fixed ceiling: workers can never create workers, and there are never more than this
WORKER_TIMEOUT = 150      # seconds the manager waits for the crew in one pass
SIDELINE = 1800           # a worker that keeps failing sits out for 30 minutes


def _worker_cap():
    try:
        return max(1, min(int(os.environ.get("JARVIS_MAX_WORKERS", MAX_WORKERS_HARD)), MAX_WORKERS_HARD))
    except ValueError:
        return MAX_WORKERS_HARD


class Worker:
    """One worker scans one pair for the manager. It reads data and reports what it found. It holds a read-only broker view
    (no way to place an order) and has no way to hire another worker: only the manager keeps the roster."""
    def __init__(self, inst):
        self.inst, self.state, self.errors, self.scans = inst, "idle", 0, 0
        self.last = self.err = self.thread = self.results = None
        self.sidelined_until = 0.0

    def run(self, ctx, gate):
        with gate:                                        # only a few work at once, whatever the crew size
            self.state = "scanning"
            try:
                self.results = trader.scan_pair(ctx, self.inst)
                self.errors, self.scans, self.last, self.state = 0, self.scans + 1, time.time(), "idle"
            except Exception as e:
                self.results, self.err = None, str(e)[:100]
                self.errors, self.state = self.errors + 1, "error"


class Manager:
    CAUTION_DD, HALT_DD = 5.0, 10.0          # percent drawdown from the equity peak
    MIN_TRADES, BENCH_DAYS = 10, 7           # live trades before a strategy is judged; days it sits out

    def __init__(self, report):
        self.report = report                  # report(kind, text, prop=None) -> bool, goes to Jarvis
        self.playbook, self.ledger = Playbook(), Ledger()
        self.working, self.mode, self.gen = False, "propose", 0
        self.pairs, self.only = trader.universe(), None
        self.tier, self.fails, self.seen = "normal", 0, set()
        self.cycles, self.last_error, self.acct, self.eq, self.dd = 0, None, "", 0.0, 0.0
        self.workers, self.max_workers = {}, _worker_cap()

    def say(self, kind, text, prop=None):
        try:
            return bool(self.report(kind, text, prop))
        except Exception as e:
            print("report error:", e)
            return False

    # ------------------------------------------------------------ orders from the boss
    def start(self):
        if trader.killed():
            return False
        if not self.working:
            self.working, self.gen = True, self.gen + 1
            threading.Thread(target=self._loop, args=(self.gen,), daemon=True).start()
        return True

    def stop(self):
        self.working = False
        self.workers.clear()                              # the crew is retired when the manager stops

    def set_mode(self, mode):
        self.mode, self.fails = mode, 0

    def focus(self, pairs=None, strategies=None, reset=False):
        if reset:
            self.pairs, self.only = trader.universe(), None
        if pairs:
            self.pairs = list(pairs)
        if strategies:
            self.only = set(strategies)

    def set_worker_limit(self, n):
        self.max_workers = max(1, min(int(n), MAX_WORKERS_HARD))
        return self.max_workers

    def workers_report(self):
        if self.max_workers <= 1:
            return "I am working alone, scanning one pair after another."
        if not self.workers:
            return f"No workers right now. When I start work I will use up to {self.max_workers} at once, one per pair."
        bits = []
        for inst, w in self.workers.items():
            s = "sidelined" if w.sidelined_until > time.time() else w.state
            bits.append(f"{inst.replace('_', ' ')} {s} ({w.scans} scans" + (f", {w.errors} errors" if w.errors else "") + ")")
        return f"I have {len(self.workers)} workers, {self.max_workers} working at once: " + "; ".join(bits) + "."

    def _run_workers(self, ctx):
        """Hire one worker per pair (never more than the ceiling), let them scan in parallel, and collect what they found."""
        wctx = dict(ctx, b=trader.ReadOnly(ctx["b"]))
        for inst in self.pairs[:MAX_WORKERS_HARD]:
            self.workers.setdefault(inst, Worker(inst))
        for inst in [i for i in self.workers if i not in self.pairs]:
            del self.workers[inst]                        # retire workers whose pair is no longer wanted
        gate, crew, now = threading.BoundedSemaphore(self.max_workers), [], time.time()
        for w in list(self.workers.values()):
            if w.sidelined_until > now:
                continue
            if w.thread and w.thread.is_alive():
                w.state = "busy"
                continue
            w.results, w.thread = None, threading.Thread(target=w.run, args=(wctx, gate), daemon=True)
            w.thread.start()
            crew.append(w)
        deadline, results = time.time() + WORKER_TIMEOUT, []
        for w in crew:
            w.thread.join(max(0.0, deadline - time.time()))
            if w.thread.is_alive():
                w.errors, w.err, w.state = w.errors + 1, "timed out", "timeout"
            elif w.results is not None:
                results += w.results
            if w.errors >= 3 and w.sidelined_until <= time.time():
                w.sidelined_until = time.time() + SIDELINE
                self.say("alert", f"My {w.inst.replace('_', ' ')} worker keeps failing ({w.err}), so I sidelined it for 30 minutes. The others carry on.")
        return results

    def reset_peak(self):
        self.ledger.reset_peak(self.acct, self.eq)
        self.tier, trader.RISK_SCALE = "normal", 1.0

    # ------------------------------------------------------------ reports to the boss
    def status(self):
        return dict(working=self.working, mode=self.mode, tier=self.tier, pairs=self.pairs, max_workers=self.max_workers,
                    workers=[dict(pair=i, state=w.state, scans=w.scans, errors=w.errors) for i, w in self.workers.items()],
                    only=sorted(self.only) if self.only else None, benched=sorted(self.ledger.benched()),
                    cycles=self.cycles, trades=self.ledger.stats()["n"], error=self.last_error)

    def performance(self):
        o = self.ledger.stats()
        if not o["n"]:
            return "I have no closed trades yet, so there is nothing to judge."
        text = (f"{o['n']} closed trades: {o['win']:.0f} percent wins, {o['expectancy']:+.2f} dollars per trade on average, "
                f"profit factor {o['pf']:.2f}, {o['total']:+.2f} dollars in total.")
        per = []
        for name in self.playbook.strategies:
            s = self.ledger.stats(name)
            if s["n"]:
                per.append(f"{name}: {s['n']} trades, {s['total']:+.0f} dollars")
        return text + (" By strategy: " + "; ".join(per) + "." if per else "")

    def briefing(self):
        st = self.status()
        line = (f"I am {'at work' if st['working'] else 'resting'}, in {st['mode']} mode, risk tier {st['tier']}"
                f" ({self.dd:.1f} percent below my equity peak)."
                + (f" Benched: {', '.join(st['benched'])}." if st["benched"] else ""))
        text = line + " " + self.performance()
        ai = brain.llm_once(
            "You are the manager of scORPio zilat's trading desk and you report to Jarvis, the boss. You may only advise. "
            "You cannot change risk limits or override the kill switch. Be honest, specific and brief: two sentences, plain text.",
            f"Desk state: {json.dumps(st)}. Drawdown from peak: {self.dd:.1f} percent. Results: {self.performance()} "
            "Give your honest assessment and one suggestion for the boss.")
        return text + (" My assessment: " + ai if ai else "")

    # ------------------------------------------------------------ the work
    def _loop(self, gen):
        while self.working and gen == self.gen:
            try:
                self.cycle()
            except Exception as e:
                self.last_error = str(e)[:140]
                if self.last_error != getattr(self, "_err_said", None):
                    self._err_said = self.last_error
                    self.say("alert", "Boss, I hit a problem: " + self.last_error)
            for _ in range(LOOP_SECONDS):
                if not (self.working and gen == self.gen):
                    break
                time.sleep(1)

    def cycle(self):
        """One pass of the job: check the kill switch, learn from results, manage risk, scan, then propose or trade."""
        self.cycles += 1
        if trader.killed():
            if self.working:
                self.stop()
                self.mode = "propose"
                self.say("alert", "The kill switch is active, so I have stopped work and will place no trades.")
            return
        b = trader.broker()
        self._learn(b)
        try:
            self._manage(b)
        except Exception as e:
            print("manage error:", e)
        self._survive(b)
        if self.tier == "halt":
            return
        off = self.ledger.benched()
        if self.only:
            off = off | (set(self.playbook.strategies) - self.only)
        trader.DISABLED.clear()
        trader.DISABLED.update(off)
        if self.max_workers <= 1:
            res = trader.scan(self.pairs)                 # working alone
        else:
            ctx, early = trader.scan_context()
            res = early if early is not None else trader.choose(self._run_workers(ctx), ctx, self.pairs)
        if res.get("halt"):
            if self.mode == "auto":
                self.mode = "propose"
                self.say("alert", res["text"] + " I dropped back to proposal mode.")
            return
        p = res.get("proposal")
        if not p or (p["inst"], p["bar"]) in self.seen:
            return
        key = (p["inst"], p["bar"])
        if self.mode == "auto" and os.environ.get("JARVIS_AUTOPILOT_ALLOWED") != "1":
            self.mode = "propose"
            self.say("alert", "Autopilot is locked on the server, so I am back to proposal mode.")
        if self.mode == "auto":
            self.seen.add(key)
            try:
                msg = trader.execute(p)
            except Exception as e:
                msg = "Order failed: " + str(e)[:120]
            self.fails = 0 if msg.startswith("Done") else self.fails + 1
            text = (f"Manager traded on autopilot: {'buy' if p['units'] > 0 else 'sell'} {p['inst'].replace('_', ' ')} "
                    f"using {p['strat']}, risking about {p['risk']:.0f} dollars. {msg}")
            if self.fails >= 2:
                self.mode = "propose"
                text += " Two orders in a row failed, so I handed control back to proposal mode."
            self.say("trade", text)
        elif self.say("proposal", "Boss, I found a setup. " + res["text"], prop=p):
            self.seen.add(key)

    def _manage(self, b):
        """Trade management: once one of my trades is up one risk unit (1R), move its stop to break-even plus a sliver."""
        if os.environ.get("JARVIS_BREAKEVEN", "1") == "0":
            return
        mine = [p for p in b.open_positions() if p.get("ours")]
        book = self.ledger.d.setdefault("open", {})
        live = {str(p["id"]) for p in mine}
        for k in [k for k in book if k not in live]:
            del book[k]
        for p in mine:
            rec = book.setdefault(str(p["id"]), {"risk": abs(p["entry"] - p["sl"]) if p["sl"] else 0.0, "be": False})
            if rec["be"] or rec["risk"] <= 0:
                continue
            if (p["price"] - p["entry"]) * p["side"] >= rec["risk"]:
                if b.move_sl(p, p["entry"] + p["side"] * 0.1 * rec["risk"]):
                    rec["be"] = True
                    self.say("trade", f"{p['inst'].replace('_', ' ')} is up one risk unit, so I moved its stop to break-even.")
        self.ledger.save()

    def _learn(self, b):
        """Learn from reality: record closed trades, and bench a strategy that keeps losing live."""
        since = int(max(self.ledger.d["last"] - 3600, time.time() - 14 * 86400))
        for t in b.closed_trades(since):
            rec = dict(id=f"{getattr(b, 'acct', '')}:{t['id']}", strat=t.get("strat") or "unknown",
                       inst=t["inst"], pl=t["pl"], t=t["t"])
            if self.ledger.add(rec):
                self.say("trade", f"A trade closed: {rec['inst'].replace('_', ' ')} {rec['pl']:+.2f} dollars ({rec['strat']}).")
        for name in self.playbook.strategies:
            s = self.ledger.stats(name)
            if s["n"] >= self.MIN_TRADES and s["expectancy"] < 0 and s["pf"] < 1 and name not in self.ledger.benched():
                self.ledger.bench(name, self.BENCH_DAYS)
                self.say("alert", f"I benched {name} for {self.BENCH_DAYS} days: {s['n']} live trades, "
                                  f"{s['expectancy']:+.2f} dollars each on average, profit factor {s['pf']:.2f}. I will retest it afterwards.")

    def _survive(self, b):
        """Survival tiers by drawdown from the equity peak: normal, caution (half risk), halt (no new trades)."""
        self.acct, self.eq = str(getattr(b, "acct", "")), b.equity()
        peak = self.ledger.peak(self.acct, self.eq)
        self.dd = (peak - self.eq) / peak * 100 if peak else 0.0
        tier = "halt" if self.dd >= self.HALT_DD else "caution" if self.dd >= self.CAUTION_DD else "normal"
        trader.RISK_SCALE = {"halt": 0.0, "caution": 0.5, "normal": 1.0}[tier]
        if tier != self.tier:
            self.tier = tier
            self.say("alert", {
                "halt": f"Equity is {self.dd:.1f} percent below its peak, so I have stopped opening trades. Tell me to reset the drawdown once you have reviewed things.",
                "caution": f"Equity is {self.dd:.1f} percent below its peak, so I have halved my risk per trade.",
                "normal": "Drawdown has recovered, so I am back to full risk."}[tier])
