# scORPio zilat — phone app

An installable phone app (PWA) with the orb face, voice, and live trading control. Your phone is the remote;
a small **server on your computer** does the real work, so your broker keys never touch the phone.

```
Phone app  <--(token)-->  server.py (your PC / Raspberry Pi / VPS)  -->  OANDA + Claude
```

## 1. Start the server (on your computer)
1. Install Python 3.9+. Copy `.env.example` to `.env` and add your keys (OANDA **practice** account first; optional Anthropic key for answers to anything).
2. Run `run_windows.bat` (Windows) or `./run_mac_linux.sh` (Mac/Linux), or `pip install -r requirements.txt` then `python server.py --lan`.
3. It prints your **access token** and the address to open on your phone.

## Your own app link (opens on its own, not inside Claude)
Install **cloudflared** (free, no account): https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/
then run the server with `--share` (the run scripts already do). It prints a line like:

    >>> YOUR APP LINK <<<   https://something.trycloudflare.com/#t=YOUR-TOKEN

Open that on your phone: it logs you in, the mic works (it is https), and you can **Add to Home Screen** to install it as an app.
Keep the link secret (it contains your token). The link works while the server is running and changes each time you start it;
for a permanent address use a named Cloudflare tunnel or Tailscale (`tailscale serve --bg 8765`). Five wrong tokens lock the API for a minute.

## Jarvis is the boss, the manager does the work
```
You  -->  JARVIS (boss: understands you, speaks, asks your approval)  -->  MANAGER (works, learns, reports)  -->  broker
```
- **The manager has been given everything Jarvis knows** (her "playbook"): all 7 strategies, the ~38 teaching topics, and the hard rules.
  Ask "what does the manager know".
- **You only talk to Jarvis.** He passes your orders on. The manager never talks to you directly; she reports to Jarvis and he tells you.

| Tell Jarvis | What he does |
|---|---|
| "start work" / "get to work" / "watch the market" | Sends the manager to work: she scans every 5 minutes and reports setups. Trades still need your **yes** |
| "autopilot on" | Authorises the manager to trade without asking (locked unless `JARVIS_AUTOPILOT_ALLOWED=1`; real accounts need "confirm autopilot") |
| "stop work" / "stop autopilot" | Stops her / hands her back to proposal mode |
| "how many workers" / "use 3 workers" | Shows the crew, or sets how many scan at once (1 to 8) |
| "focus on EURUSD and GBPUSD", "only trade the 4 hour range" | Narrows her pairs or strategies. "reset focus" undoes it |
| "how is she doing" / "report" | The manager's briefing: live results, her risk tier, benched strategies (plus a Claude assessment if you set an Anthropic key) |
| "activate the kill switch" / "release the kill switch" | Creates or deletes a file named `KILL_SWITCH` next to the server: **nobody** can place a trade while it exists. Creating that file by hand works too |
| "reset the drawdown" | Resets her equity peak after you have reviewed a halt |

**How she learns (honestly):** she records every closed trade (by strategy) and uses simple rules, not machine learning:
- A strategy with **10+ live trades, negative average and profit factor under 1** is **benched for 7 days**, then retested.
- **Drawdown tiers** from her equity peak: under 5% normal, **5% half risk**, **10% no new trades** until you reset.
- Everything she does stays inside the hard limits (risk %, open trades, trades per day, daily loss stop, kill switch). She cannot raise them.
- Her results are saved in `~/.jarvis_cache/manager.json`. Deposits or withdrawals move the equity peak: say "reset the drawdown" after one.

## Who built her, and the welcome
- She knows she was **built by Monarch Manaois**, her boss. Ask "who built you", "who made you", "who is your creator" and she says so (and, honestly, that her AI answers run on Claude, made by Anthropic). Ask "who am I" and she tells you.
- Every time the app opens she **welcomes you by name**, for example "Good morning, Monarch. Welcome back. scORPio zilat is online and ready." The text appears at once. The spoken greeting starts straight away where your phone allows it, otherwise on your first tap (phones block sound until you touch the screen).
- This is built in: "forget everything" erases memories but never who built her. To change it on the server, set `JARVIS_OWNER_NAME` and `JARVIS_CREATOR` in `.env`. To change the name she greets you with, say "call me ..." (the builder never changes).

## The manager's workers
When she starts work, the manager hires **one worker per pair** (up to 8) and they scan **in parallel**, so a full scan takes about as long as the slowest pair instead of all of them added up.
- **Workers only read.** A worker is given a read-only view of your broker: it can fetch prices and history, and it has **no way to place, move or close an order**. It scans its pair, runs the strategies and the profit test, and hands the result to the manager.
- **Only the manager decides.** She collects the results, drops anything that would stack the same currency exposure, picks the single best-evidenced setup, and passes it to Jarvis (or trades it herself only on authorised autopilot). All the limits, the kill switch and your yes still apply.
- **Capped, and no copying.** There are never more than **8** workers. Workers cannot hire other workers; only the manager keeps the roster, and the crew is retired when you say "stop work" (or when you focus on fewer pairs).
- **A crash stays small.** If one pair's data feed fails, the other workers carry on. After 3 failures in a row that worker is **sidelined for 30 minutes** and she tells you. A stuck worker times out after 150 seconds and never freezes the others.
- **MetaTrader 5:** it talks to a single terminal, so its calls are queued one at a time. The crew still helps with the analysis, but the speed-up is largest with OANDA, where requests run truly in parallel.
- Say: "how many workers do you have", "use 3 workers" (maximum 8; `JARVIS_MAX_WORKERS` sets the default), "use one worker" (she works alone, the way she did before).
- What it does **not** change: the strategies, the profit test, the risk limits. Workers make scanning faster and more robust. They do not make her more profitable.

## Markets: a TradingView-style section (works with no server)
Tap the chart button at the top (or say "show the EURUSD chart", "show the scanner", "show the heat map", "open the calendar"). Tabs:
- **Chart:** a live TradingView chart. Pick the pair (7 majors + gold) and timeframe (5m, 15m, 1h, 4h, 1D); add indicators and drawings from its own toolbar.
- **Scanner:** TradingView's forex screener (overview, performance, technical, oscillators, moving averages) for the whole market.
- **Signals:** its technical gauge (strong sell to strong buy) for the chosen pair and timeframe.
- **Heat map** of the 8 currencies, and an **economic calendar** (US, euro area, UK, Japan, Canada, Switzerland, Australia, NZ).
With no server, "scan the market" opens the scanner for you and says plainly that she cannot run her own scan.
**What this is and is not:** these are TradingView's free embedded widgets (their data, their terms, their attribution link, which stays under every widget).
They are separate pages, so **she cannot read them**: this section is for you to look at the market. Her own scan, with the backtested profit test, uses your broker's data through the server.
They only load from a real hosted copy (the server link, GitHub Pages, the native app). The preview inside Claude blocks outside content, so it shows a button that opens TradingView instead.

## Memory and her voice
**She remembers.** Everything is saved on **your server** in `~/.jarvis_cache` (so it survives restarts and follows you from phone to phone):
- `memory.json`: your name, how you like to be addressed, and the facts you asked her to keep.
- `journal.jsonl`: **every conversation and every event** (proposals, trades, manager reports), in order. It is never trimmed.
- The manager's trade ledger (`manager.json`) is separate and is what her learning uses.

Say it naturally:
| Say | What happens |
|---|---|
| "my name is Amara" / "call me boss" | She uses it from then on (the old stock "sir" becomes your name, or "boss") |
| "remember that I only trade the London session" | Saved. She also quietly keeps stated preferences like "I never trade Fridays" |
| "what do you remember about me" | Reads back your name and facts |
| "what did we talk about today" / "yesterday" | Your questions from that day |
| "what happened today" | Trades proposed, manager reports, benchings, break-even moves |
| "repeat that" / "what did you say" | Repeats her last answer (works with or without an AI key) |
| "what was my last question" | Reads back what you just asked |
| "and what about gold?" | A follow-up: after a scan she scans gold; after a topic she explains the new one |
| "forget that I like gold" | Removes that fact |
| "forget everything" then "confirm forget everything" | Erases memory and the journal (never your trade history) |

When AI answers are on, each question sends Claude your name, your saved facts, the last 24 messages of the conversation (including scan results and your commands) and the last few trading events, so she answers as someone who knows you.
The whole journal is not sent. Memory is stored as plain text on your computer: do not type passwords or keys to her, and wipe it before giving the machine away.
In demo mode (no server) she only remembers your name and facts in that browser.

**Only a female voice.** She speaks with a female voice or not at all in a male one: the app only picks voices with female names or labels (Google UK/US English, Zira, Samantha, Karen, Moira and so on) and never a male voice.
If your phone has no female English voice installed, she says so and raises her pitch instead. Install one in your phone's text-to-speech settings (Android: Settings > Text-to-speech; iPhone: Settings > Accessibility > Spoken Content > Voices).
Her persona is a woman in every AI answer, and she will say so if you ask.

## Only setups with evidence behind them
Nobody can know that a trade will win, and no setting makes this app win every trade: even a good strategy loses often.
What she does is refuse any setup that cannot show **strong, consistent evidence of profit on past data**. A setup is only proposed when its backtest passes **all** of these:
- at least **40 trades** (about a year of 5-minute data, 250 days of 1-minute data, 5,000 hourly candles), counting **only the trades the live rules would allow** (trading hours, news blackouts, Fridays)
- average **+0.20 R per trade after costs**, and a **profit factor of 1.30 or more**
- **95% confidence** that the true edge is above zero (a bootstrap test), so a lucky streak is not enough
- profitable in **at least 3 of 4 time periods, including the most recent**, so an edge that has faded is rejected
- still profitable **without its two best trades**, and **still profitable if costs double**
- a worst losing streak under **12 R**
When she skips a setup she says which test it failed. Every proposal shows its trade count and its confidence figure.
How strict is it? In simulation, a strategy with **no edge** passed this gate about **2 to 3 percent** of the time, a real edge of **+0.35 R** passed about **57 percent** of the time, and a strong edge of **+0.6 R** about **93 percent**. So it is deliberately choosy and will often stand aside.
Limits: it judges the past. Markets change, and testing many strategies and pairs means a few no-edge ones will slip through by luck. That is why the manager also benches any strategy that loses on live trades, halves risk in drawdown, and every trade has a stop loss.
Tune it with `JARVIS_MIN_TRADES`, `JARVIS_MIN_EXPECTANCY`, `JARVIS_MIN_PF`, `JARVIS_MIN_CONFIDENCE`, `JARVIS_MAX_BACKTEST_DD`. Loosening any of them means trading weaker evidence.

## News calendar and emergency protection
**Scheduled news (built in, checked against the official sources).** Window: 30 minutes before to 60 minutes after the announcement.
A US event pauses every pair; a currency's own central bank pauses only the pairs that contain that currency.

| Event | Pauses | Built-in dates | After that |
|---|---|---|---|
| Fed rate decision (14:00 NY) | all pairs | 2024 to Jan 2028 | every Wednesday 13:30-15:00 |
| US jobs report (08:30 NY) | all pairs | official 2026 dates | every Thursday and Friday 08:00-09:30 |
| US CPI (08:30 NY) | all pairs | official 2026 dates | weekdays 9th-16th, 08:00-09:30 |
| ECB (14:15 Berlin) | EUR pairs | 2025 to Apr 2027 | every Thursday |
| Bank of England (12:00 London) | GBP pairs | 2025 to Dec 2027 | every Thursday |
| Bank of Canada (09:45 ET) | CAD pairs | Sep 2026 to Dec 2027 | every Wednesday |
| SNB (09:30 Zurich) | CHF pairs | 2025 to Dec 2027 | every Thursday |

Times follow daylight saving in each country (for example the ECB moves an hour against New York for a week in late October).
The "after that" column is a wider recurring window on the weekday the institution always uses, so a missing date never leaves you unprotected.
The RBA, RBNZ and Bank of Japan announce before 02:00 New York time, outside my trading hours, so I never open trades near them.
When an institution publishes more dates, add them to `blackouts.txt` next to the server:
`ECB 2027-06-10`, `ECB-THROUGH 2027-12-31` (ends the fallback), the same for `FOMC`, `NFP`, `CPI`, `BOE`, `BOC`, `SNB`,
or any event: `2026-11-10 08:30, 30, 60, my event`.

**Emergency and unscheduled news** (an emergency central-bank meeting, a shock) cannot be on any calendar, so there is a **volatility circuit breaker**:
if the last hourly bar is more than 3x the normal range (ATR), or price is already moving that fast inside the current hour, she
**stands aside on that pair** until it calms, and says why. Wide spreads at the moment of the order are refused too. Tune with `JARVIS_SPIKE_ATR`.
It reacts after the first big move; it cannot predict one, and it does not cover the minute-chart backtests.

## Extra safety and trade management
These apply to Jarvis's own trades and to the manager's, on autopilot or not.
- **Session and news filter:** new trades only Mon-Fri, 02:00-15:00 New York time, none late on Friday, and **blackouts** around Fed decisions
  (2024-2028 built in) and the US jobs report (official 2026 dates). Add your own events to `blackouts.txt` next to the server, one per line:
  `2026-11-10 08:30, 30, 60, US CPI` (minutes before, minutes after, name). Change hours with `JARVIS_HOURS=2-15`; `JARVIS_GUARDS=off` disables this filter.
  Note: backtests cover all hours, live trading uses these hours only.
- **No stacking:** she will not take a second trade with the same-direction exposure to one currency (buy EURUSD then buy GBPUSD is one big short-USD bet). `JARVIS_MAX_CCY_EXPOSURE`.
- **Spread check:** at the moment of the order, a spread above 15% of the stop distance is refused.
- **Break-even stop:** once one of her trades is up 1R, the manager moves its stop to entry plus a sliver, once. `JARVIS_BREAKEVEN=0` turns it off.
- **Close everything:** "close all trades" asks you to confirm, then closes only the trades **the app opened** and stops the manager. Your own trades are never touched.
- **What's open:** "what's open" lists open trades with profit or loss. **Journal:** "export my journal" saves `journal.csv` (closed trades by strategy).

## Gold (XAUUSD)
Ask "scan XAUUSD" or "should I buy gold". She uses a wider cost assumption (`JARVIS_GOLD_COST`, dollars per ounce), sizes by
dollars per ounce (on MT5 one standard lot is 100 oz), and backtests it like any other pair before proposing a trade.
Gold is not in the default scan unless `JARVIS_INCLUDE_GOLD=1`. On Exness the symbol may be `XAUUSDm` or similar; the suffix setting handles it.
Gold moves in much bigger swings than forex pairs, so keep risk low and run it on demo first.

## 1b. Exness + MetaTrader 5 (what makes it "live")
1. **Windows only** (the `MetaTrader5` Python package needs it). Use your PC, or a Windows VPS to run 24/7.
2. Install MT5 from Exness and log in to your account. In MT5: turn **Algo Trading** ON, tick *Tools > Options > Expert Advisors > Allow algorithmic trading*, and set *Charts > Max bars in chart* to Unlimited.
3. In `.env` set `JARVIS_BROKER=mt5`. If your symbols look like `EURUSDm`, set `JARVIS_MT5_SUFFIX=m`.
4. The account must be in **USD** (cent accounts are refused). The app reads whether the account is demo or real from MT5 itself.
5. Real account: set `JARVIS_ALLOW_LIVE=1`. Without it a real Exness account is refused.

### Autopilot
- Off by default. Allow it with `JARVIS_AUTOPILOT_ALLOWED=1` in `.env`, then tap 🤖 in the app (or say "autopilot on").
- On a real account she warns you and you must say/tap **confirm autopilot**. Say "stop autopilot" or tap 🤖 to turn it off.
- On autopilot she scans every 5 minutes and places trades that pass their backtest, **without asking**. Guard rails: max risk per trade
  (`JARVIS_RISK_PCT`, capped at 2), 3 trades a day, 3 open trades, a **3% daily loss stop** (`JARVIS_MAX_DAILY_LOSS`), and autopilot switches
  itself off after two failed orders. The daily-loss baseline is your equity at the first reading each day.
- Every trade carries a stop loss and take profit. She reports each autopilot trade in the app.

## 2. Open it on your phone
- Same Wi-Fi: open the printed `http://<ip>:8765` address.
- Tap ⚙, paste the **access token**, tap *Save & connect*. The badge turns to *practice*.
- **Install it:** iPhone Safari → Share → *Add to Home Screen*. Android Chrome → menu → *Install app*.

## 3. Voice needs https
Browsers only allow the microphone on https pages. Typing and spoken answers work on plain http, but for the mic
(and for using the app away from home) put https in front of the server:
- **Tailscale** (private, recommended): install it on the computer and the phone, then `tailscale serve --bg 8765`.
- **Cloudflare quick tunnel**: `cloudflared tunnel --url http://localhost:8765` (public link; your token still protects the API).
Then open that https address on your phone instead.

## Using it
| Do this | What happens |
|---|---|
| Type or tap 🎙 and say "scan the market" / "analyze EURUSD" | Live prices, 7 strategies, backtest, proposal |
| Tap 👁 | Market watch: she scans every 5 min and speaks when a setup passes its backtest (keep the app open) |
| Tap **YES, EXECUTE** / **NO** | Places the order or cancels. Nothing is placed without your YES |
| "explain the CR model", "explain RSI" | Teaching answers |

Strategies: trend pullback, channel breakout, range reversion, MACD momentum, support reversal, the **9 AM CR model**, and the
**4 Hour Range** strategy (visual guides in `docs/`).

## Safety
- Every API call needs the token (wrong guesses are slowed down). The server listens on this computer only unless you pass `--lan`.
- Practice account by default. Live money needs `OANDA_ENV=live` **and** `JARVIS_ALLOW_LIVE=1`; the badge turns red when live.
- 1% risk per trade (max 2%), leverage capped at 10x, 3 trades/day max, proposals expire after 2 minutes, and she aborts if price moved too far.
- Do not expose the server to the internet without https and a strong token.

## Known limits
- The Exness/MT5 code was tested only against a simulated MT5, **never against a real terminal or a real Exness account**. Run it on an Exness demo account first: it uses the identical code path and will reveal anything I could not test (symbol names, lot limits, stop levels).
- Autopilot will have losing trades and losing days; no strategy is guaranteed.
- This is a web app installed to your home screen, not an App Store / Play Store app. Store packaging (Capacitor) is a separate step.
- The server must be running, and the app must be open to hear market-watch alerts (no push notifications yet).
- A good backtest does not predict profit. Educational software, not financial advice. Forex carries a high risk of loss.

## Troubleshooting: "error 405" or "this address is not my server"
A real scORPio server never answers 405. A **405 (or 404) means the address in front of the app is a plain website, not your server**:
websites reject the app's requests. The usual causes:
- You are using the **preview inside Claude**, or a copy of the app you uploaded to a static host (Netlify, GitHub Pages...). Those cannot run the server.
  Open the **app link your server printed** (`https://....trycloudflare.com/#t=...`) instead, or paste that link in Settings under *Server address*.
- You filled in the wrong *Server address*. Check it: open `YOUR-ADDRESS/api/health` in a browser. A real server shows
  `{"app": "scorpio-zilat", "ok": true}`. Anything else (an error page, 405, a website) means the address is wrong.
- The server is not running (the link stops working when the server window is closed), or the link changed after a restart. Start it again and use the new link.
