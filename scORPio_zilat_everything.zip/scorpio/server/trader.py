"""
trader.py - live data, 5 strategies, per-pair backtest, and CONFIRMED execution for JARVIS (OANDA v20).
Strategies: trend pullback, channel breakout, range reversion, MACD momentum, support reversal,
plus the 9 AM CR model (8 AM range sweep + IFVG + order block on the 1-minute chart, New York time)
and the 4 Hour Range strategy (failed breakout of the first 4H candle's range, on the 5-minute chart).

Setup (free practice account at oanda.com):
  1. Create a fxTrade *Practice* account, then generate an API token (My Services > API).
  2. export OANDA_TOKEN=...   export OANDA_ACCOUNT=101-001-xxxxxxx-001
  Optional: JARVIS_RISK_PCT=1 (max 2)   OANDA_ENV=practice (default)
  Real money needs BOTH OANDA_ENV=live and JARVIS_ALLOW_LIVE=1. Test on practice for weeks first.

Nothing is ever placed unless you say yes to a specific proposal. Account currency must be USD.
"""
import os, re, sys, json, time, threading, urllib.request, urllib.error
import numpy as np
import guards
from datetime import datetime, timezone, timedelta
try:
    from zoneinfo import ZoneInfo
    TZ = ZoneInfo(os.environ.get("JARVIS_TZ", "America/New_York"))   # local market time (Windows: pip install tzdata)
except Exception:
    TZ = timezone(timedelta(hours=-5))

PAIRS = ["EUR_USD", "GBP_USD", "USD_JPY", "AUD_USD", "NZD_USD", "USD_CAD", "USD_CHF"]
GOLD = "XAU_USD"      # gold in US dollars per ounce (MT5: XAUUSD, often with a suffix)

def universe():
    """Default scan list: the 7 majors, plus gold when JARVIS_INCLUDE_GOLD=1. Gold is always available on request."""
    return PAIRS + ([GOLD] if os.environ.get("JARVIS_INCLUDE_GOLD") == "1" else [])

def cost_dec(inst):
    """(assumed spread + slippage in price units, price decimals). Gold: JARVIS_GOLD_COST dollars per ounce."""
    if inst.startswith("XAU"):
        return float(os.environ.get("JARVIS_GOLD_COST", "0.30")), 3
    if "JPY" in inst:
        return 0.012, 3
    return 0.00012, 5
GRAN, COUNT = "H1", 5000
MAX_TRADES_PER_DAY, MAX_LEVERAGE, SLIPPAGE_ATR = 3, 10, 0.25
SETUP_HELP = ("Trading is not connected yet, sir. Set JARVIS_BROKER=mt5 for Exness and MetaTrader 5, "
              "or OANDA_TOKEN and OANDA_ACCOUNT for OANDA, then ask me again.")
_trades_today = {"day": None, "n": 0}
RISK_SCALE = 1.0            # set by the manager: 1 normal, 0.5 in drawdown caution, 0 when halted
DISABLED = set()            # strategies the manager has benched or the boss has switched off

def _base_dir():
    return os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))

KILL_FILE = os.environ.get("JARVIS_KILL_FILE") or os.path.join(_base_dir(), "KILL_SWITCH")

def killed():
    """True while a file named KILL_SWITCH exists next to the server: no new orders, from anyone."""
    return os.path.exists(KILL_FILE)


def configured():
    if os.environ.get("JARVIS_BROKER", "oanda").lower() == "mt5":
        return True                                       # uses the logged-in MT5 terminal
    return bool(os.environ.get("OANDA_TOKEN") and os.environ.get("OANDA_ACCOUNT"))

_MT5_LOCK = threading.RLock()


class _Serial:
    """MetaTrader 5 talks to one terminal, so its calls are queued one at a time even when workers run in parallel."""
    def __init__(self, b):
        self._b = b

    def __getattr__(self, name):
        attr = getattr(self._b, name)
        if not callable(attr):
            return attr

        def call(*a, **k):
            with _MT5_LOCK:
                return attr(*a, **k)
        return call


def broker():
    """JARVIS_BROKER=mt5 -> MetaTrader 5 / Exness, otherwise OANDA."""
    if os.environ.get("JARVIS_BROKER", "oanda").lower() == "mt5":
        import mt5_broker
        return _Serial(mt5_broker.MT5())
    return Oanda()

_mode = {}
def broker_mode():
    """'practice' or 'live' (anything else is treated as live for safety)."""
    if os.environ.get("JARVIS_BROKER", "oanda").lower() != "mt5":
        return os.environ.get("OANDA_ENV", "practice").lower()
    if "m" in _mode:
        return _mode["m"]
    if time.time() - _mode.get("fail", 0) < 60:
        return "unknown"
    try:
        _mode["m"] = broker().env
        return _mode["m"]
    except RuntimeError as e:
        _mode["fail"] = time.time()
        return "live" if "REAL" in str(e) else "unknown"

MAX_OPEN = int(os.environ.get("JARVIS_MAX_OPEN", "3"))
MAX_DAILY_LOSS_PCT = float(os.environ.get("JARVIS_MAX_DAILY_LOSS", "3"))

def daily_guard(b):
    """Block new trades once today's equity is down MAX_DAILY_LOSS_PCT from the day's first reading."""
    path = os.path.join(os.path.expanduser("~"), ".jarvis_cache", "day_equity.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    today, eq = time.strftime("%Y-%m-%d"), b.equity()
    try:
        st = json.load(open(path))
    except Exception:
        st = {}
    if st.get("day") != today or st.get("acct") != str(getattr(b, "acct", "")):
        st = {"day": today, "eq": eq, "acct": str(getattr(b, "acct", ""))}
        json.dump(st, open(path, "w"))
    loss = (st["eq"] - eq) / st["eq"] * 100 if st["eq"] else 0
    if loss >= MAX_DAILY_LOSS_PCT:
        return f"Daily loss limit of {MAX_DAILY_LOSS_PCT:g} percent reached, {loss:.1f} percent down today. No new trades until tomorrow."
    return None

def find_pairs(s):
    raw = s.lower()
    letters = "".join(ch for ch in raw if ch.isalpha())
    out = [p for p in PAIRS + [GOLD] if p.replace("_", "").lower() in letters]
    if re.search(r"\bgold\b", raw) and GOLD not in out:
        out.append(GOLD)
    return out

def find_pair(s):
    f = find_pairs(s)
    return f[0] if f else None

def risk_pct():
    """Per-trade risk in percent: the configured value (0.1 to 2) times the manager's drawdown scale."""
    try:
        base = min(max(float(os.environ.get("JARVIS_RISK_PCT", 1)), 0.1), 2.0)
    except ValueError:
        base = 1.0
    return base * RISK_SCALE

def _ts(t):
    """Bar time as epoch seconds, from either an MT5 epoch string or an OANDA ISO string."""
    try:
        return int(t)
    except (TypeError, ValueError):
        return _epoch(t)

def _epoch(t):   # OANDA RFC3339 -> epoch seconds (UTC)
    return int(datetime.strptime(t[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc).timestamp())

# ----------------------------------------------------------------- broker
class Oanda:
    def __init__(self):
        env = os.environ.get("OANDA_ENV", "practice").lower()
        if env == "live" and os.environ.get("JARVIS_ALLOW_LIVE") != "1":
            raise RuntimeError("Live trading is locked. Set JARVIS_ALLOW_LIVE=1 to unlock it.")
        self.base = "https://api-fxtrade.oanda.com" if env == "live" else "https://api-fxpractice.oanda.com"
        self.acct, self.token, self.env = os.environ["OANDA_ACCOUNT"], os.environ["OANDA_TOKEN"], env

    def _req(self, method, path, body=None):
        req = urllib.request.Request(self.base + path, json.dumps(body).encode() if body else None,
                                     {"Authorization": "Bearer " + self.token, "Content-Type": "application/json"},
                                     method=method)
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"OANDA error {e.code}: {e.read().decode()[:160]}")

    def candles(self, inst):
        r = self._req("GET", f"/v3/instruments/{inst}/candles?granularity={GRAN}&count={COUNT}&price=M")["candles"]
        done = [c for c in r if c["complete"]]
        arr = lambda k: np.array([float(c["mid"][k]) for c in done])
        live = float(r[-1]["mid"]["c"])
        return dict(o=arr("o"), h=arr("h"), l=arr("l"), c=arr("c"), t=[c["time"] for c in done]), live

    def _bars_page(self, inst, start, gran):
        f = datetime.fromtimestamp(start, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000000000Z")
        r = self._req("GET", f"/v3/instruments/{inst}/candles?granularity={gran}&count=5000&price=M&from={f}")["candles"]
        return [c for c in r if c["complete"]], len(r)

    def bars_since(self, inst, start, gran="M1"):
        rows = []
        while True:
            cs, n = self._bars_page(inst, start, gran)
            rows += cs
            if n < 5000 or not cs:
                break
            start = _epoch(cs[-1]["time"]) + 60
        pick = lambda k: np.array([float(c["mid"][k]) for c in rows])
        return dict(t=np.array([_epoch(c["time"]) for c in rows], dtype=np.int64), o=pick("o"), h=pick("h"), l=pick("l"), c=pick("c"))

    def bars_history(self, inst, gran="M1", days=None):
        days = days or {"M1": 250, "M5": 365}.get(gran, 365)
        path = os.path.join(os.path.expanduser("~"), ".jarvis_cache", f"{inst}_{gran}.npz")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        now, old = int(time.time()), None
        if os.path.exists(path):
            z = np.load(path)
            old = {k: z[k] for k in "tohlc"}
        start = int(old["t"][-1]) + 60 if old is not None and len(old["t"]) else now - days * 86400
        new = self.bars_since(inst, start, gran)
        m = new if old is None else {k: np.concatenate([old[k], new[k]]) for k in "tohlc"}
        keep = m["t"] >= now - days * 86400
        m = {k: v[keep] for k, v in m.items()}
        np.savez(path, **m)
        return m

    def m1_since(self, inst, start):
        return self.bars_since(inst, start, "M1")

    def m1_history(self, inst, days=None):
        return self.bars_history(inst, "M1", days)

    def summary(self):
        a = self._req("GET", f"/v3/accounts/{self.acct}/summary")["account"]
        return float(a["balance"]), a["currency"], int(a.get("openTradeCount", 0))

    def _prices(self, insts):
        r = self._req("GET", f"/v3/accounts/{self.acct}/pricing?instruments={','.join(insts)}")["prices"]
        return {x["instrument"]: (float(x["bids"][0]["price"]), float(x["asks"][0]["price"])) for x in r}

    def spread(self, inst):
        bid, ask = self._prices([inst])[inst]
        return ask - bid

    def open_positions(self):
        trades = self._req("GET", f"/v3/accounts/{self.acct}/openTrades")["trades"]
        px = self._prices(sorted({t["instrument"] for t in trades})) if trades else {}
        out = []
        for t in trades:
            units, bid_ask = float(t["currentUnits"]), px.get(t["instrument"], (0, 0))
            sl, tp = t.get("stopLossOrder", {}).get("price"), t.get("takeProfitOrder", {}).get("price")
            out.append(dict(id=t["id"], inst=t["instrument"], side=1 if units > 0 else -1, units=abs(units),
                            entry=float(t["price"]), sl=float(sl) if sl else None, tp=float(tp) if tp else None,
                            price=bid_ask[0] if units > 0 else bid_ask[1], pl=float(t.get("unrealizedPL", 0)),
                            ours=t.get("clientExtensions", {}).get("tag") == "scorpio"))
        return out

    def move_sl(self, pos, sl):
        r = self._req("PUT", f"/v3/accounts/{self.acct}/trades/{pos['id']}/orders", {"stopLoss": {"price": f"{sl:.5f}" if pos["entry"] < 50 else f"{sl:.3f}"}})
        return "stopLossOrderTransaction" in r or "stopLossOrderCancelTransaction" in r or bool(r)

    def close_position(self, pos):
        return "orderFillTransaction" in self._req("PUT", f"/v3/accounts/{self.acct}/trades/{pos['id']}/close", {"units": "ALL"})

    def equity(self):
        return float(self._req("GET", f"/v3/accounts/{self.acct}/summary")["account"]["NAV"])

    def open_instruments(self):
        t = self._req("GET", f"/v3/accounts/{self.acct}/openTrades")["trades"]
        return {x["instrument"] for x in t}

    def order(self, inst, units, sl, tp, dec, strat=""):
        body = {"order": {"type": "MARKET", "instrument": inst, "units": str(units), "timeInForce": "FOK",
                          "positionFill": "DEFAULT",
                          "stopLossOnFill": {"price": f"{sl:.{dec}f}"},
                          "takeProfitOnFill": {"price": f"{tp:.{dec}f}"},
                          "tradeClientExtensions": {"tag": "scorpio", "comment": strat[:30]}}}
        return self._req("POST", f"/v3/accounts/{self.acct}/orders", body)

    def closed_trades(self, since):
        """Closed trades opened by this app (tagged 'scorpio'), for the manager's ledger."""
        out = []
        for t in self._req("GET", f"/v3/accounts/{self.acct}/trades?state=CLOSED&count=200")["trades"]:
            ext = t.get("clientExtensions", {})
            if ext.get("tag") == "scorpio" and _epoch(t["closeTime"]) >= since:
                out.append(dict(id=t["id"], inst=t["instrument"], pl=float(t.get("realizedPL", 0)),
                                t=_epoch(t["closeTime"]), strat=ext.get("comment", "")))
        return out

# ----------------------------------------------------------------- indicators
def ema(x, n):
    a, out = 2 / (n + 1), np.empty_like(x)
    out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = a * x[i] + (1 - a) * out[i - 1]
    return out

def wilder(x, n):
    out = np.zeros_like(x)
    out[n] = x[1:n + 1].mean()
    for i in range(n + 1, len(x)):
        out[i] = (out[i - 1] * (n - 1) + x[i]) / n
    return out

def roll(x, n, f):
    out = np.full(len(x), np.nan)
    out[n - 1:] = f(np.lib.stride_tricks.sliding_window_view(x, n))
    return out

def prior(x):           # value as of the previous bar (no look-ahead)
    return np.concatenate([[np.nan], x[:-1]])

def indicators(d):
    o, c, h, l = d["o"], d["c"], d["h"], d["l"]
    tr = np.maximum(h[1:] - l[1:], np.maximum(abs(h[1:] - c[:-1]), abs(l[1:] - c[:-1])))
    atr = d["atr"] = wilder(np.concatenate([[0], tr]), 14)
    delta = np.diff(c, prepend=c[0])
    ag, al = wilder(np.maximum(delta, 0), 14), wilder(np.maximum(-delta, 0), 14)
    d["rsi"] = 100 - 100 / (1 + ag / np.where(al == 0, 1e-12, al))
    d["e50"], d["e200"] = ema(c, 50), ema(c, 200)
    # ADX (trend strength)
    up, dn = np.diff(h, prepend=h[0]), -np.diff(l, prepend=l[0])
    pdm, mdm = np.where((up > dn) & (up > 0), up, 0.0), np.where((dn > up) & (dn > 0), dn, 0.0)
    safe = np.where(atr > 0, atr, 1e-12)
    pdi, mdi = 100 * wilder(pdm, 14) / safe, 100 * wilder(mdm, 14) / safe
    d["adx"] = wilder(100 * abs(pdi - mdi) / np.where(pdi + mdi == 0, 1e-12, pdi + mdi), 14)
    # MACD histogram
    macd = ema(c, 12) - ema(c, 26)
    d["hist"] = macd - ema(macd, 9)
    # Bollinger Bands (20, 2)
    d["bmid"], sd = roll(c, 20, lambda w: w.mean(1)), roll(c, 20, lambda w: w.std(1))
    d["bup"], d["blo"] = d["bmid"] + 2 * sd, d["bmid"] - 2 * sd
    # Donchian / structure levels from PRIOR bars
    d["dh20"], d["dl20"] = prior(roll(h, 20, lambda w: w.max(1))), prior(roll(l, 20, lambda w: w.min(1)))
    d["sh50"], d["sl50"] = prior(roll(h, 50, lambda w: w.max(1))), prior(roll(l, 50, lambda w: w.min(1)))
    return d

# ----------------------------------------------------------------- strategies
# each returns +1 buy, -1 sell, 0 none, using only data up to bar i
def s_pullback(i, d):
    """Trend pullback: trade with the 50/200 EMA trend after a dip to the 50 EMA."""
    a, e50, e200, r = d["atr"][i], d["e50"][i], d["e200"][i], d["rsi"][i]
    o, h, l, c = d["o"][i], d["h"][i], d["l"][i], d["c"][i]
    if e50 > e200 and l <= e50 + .3 * a and c > e50 and c > o and 40 <= r <= 62:
        return 1
    if e50 < e200 and h >= e50 - .3 * a and c < e50 and c < o and 38 <= r <= 60:
        return -1
    return 0

def s_breakout(i, d):
    """Donchian breakout: close beyond the 20-bar high/low, ADX > 20, aligned with the 200 EMA."""
    c, adx = d["c"][i], d["adx"][i]
    if adx > 20 and c > d["dh20"][i] and c > d["e200"][i]:
        return 1
    if adx > 20 and c < d["dl20"][i] and c < d["e200"][i]:
        return -1
    return 0

def s_range(i, d):
    """Range mean reversion: in a low-ADX market, fade a Bollinger Band poke with an RSI extreme."""
    c, l, h, r = d["c"][i], d["l"][i], d["h"][i], d["rsi"][i]
    if d["adx"][i] < 20 and l <= d["blo"][i] and c > d["blo"][i] and r < 40:
        return 1
    if d["adx"][i] < 20 and h >= d["bup"][i] and c < d["bup"][i] and r > 60:
        return -1
    return 0

def s_macd(i, d):
    """MACD momentum: histogram flips sign in the direction of the 50/200 EMA trend."""
    hi, hp = d["hist"][i], d["hist"][i - 1]
    if hp <= 0 < hi and d["e50"][i] > d["e200"][i] and d["c"][i] > d["e200"][i]:
        return 1
    if hp >= 0 > hi and d["e50"][i] < d["e200"][i] and d["c"][i] < d["e200"][i]:
        return -1
    return 0

def s_reversal(i, d):
    """Price-action reversal: pin bar or engulfing candle at a 50-bar support/resistance level."""
    o, h, l, c, a = d["o"][i], d["h"][i], d["l"][i], d["c"][i], d["atr"][i]
    po, pc = d["o"][i - 1], d["c"][i - 1]
    rng, body = h - l, abs(c - o)
    if rng <= 0:
        return 0
    lw, uw = min(o, c) - l, h - max(o, c)
    bull = (lw >= 2 * body and lw >= .55 * rng) or (c > o and pc < po and c >= po and o <= pc)
    bear = (uw >= 2 * body and uw >= .55 * rng) or (c < o and pc > po and c <= po and o >= pc)
    if bull and l <= d["sl50"][i] + .25 * a and d["rsi"][i] < 45:
        return 1
    if bear and h >= d["sh50"][i] - .25 * a and d["rsi"][i] > 55:
        return -1
    return 0

# name: (function, stop in ATR, target in ATR)
STRATS = {
    "trend pullback":     (s_pullback, 1.5, 3.0),
    "channel breakout":   (s_breakout, 1.5, 3.0),
    "range reversion":    (s_range,    1.5, 1.5),
    "MACD momentum":      (s_macd,     1.5, 3.0),
    "support reversal":   (s_reversal, 1.5, 3.0),
}
# The profit gate. A setup is only proposed when its backtest passes ALL of these (override with the JARVIS_MIN_* settings).
MIN_TRADES = int(os.environ.get("JARVIS_MIN_TRADES", "40"))
MIN_EXPECTANCY = float(os.environ.get("JARVIS_MIN_EXPECTANCY", "0.20"))      # average R per trade after costs
MIN_PF = float(os.environ.get("JARVIS_MIN_PF", "1.30"))
MIN_CONF = float(os.environ.get("JARVIS_MIN_CONFIDENCE", "0.95"))           # bootstrap chance that the true edge is above zero
MAX_DD_R = float(os.environ.get("JARVIS_MAX_BACKTEST_DD", "12"))
# Volatility circuit breaker for UNSCHEDULED news (emergency central-bank moves, shocks): a bar bigger than this many ATRs pauses trading.
SPIKE_ATR = float(os.environ.get("JARVIS_SPIKE_ATR", "3.0"))

def _stats(R, C=None):
    """Judge a list of trade results (in R, after costs). C = the cost of each trade in R, for the doubled-cost stress test."""
    n = len(R)
    if n < 2:
        return dict(n=n, win=0, avg=0, pf=0, dd=0, conf=0.0, folds=0, ok=False, why=f"only {n} trades", half=(0, 0))
    pos, neg = R[R > 0].sum(), abs(R[R < 0].sum())
    eq = R.cumsum()
    dd = float((np.maximum.accumulate(eq) - eq).max())
    folds = [f.mean() for f in np.array_split(R, 4)] if n >= 8 else [R.mean()]
    conf = float((np.random.default_rng(7).choice(R, (2000, n)).mean(1) > 0).mean())      # bootstrap
    trimmed = np.sort(R)[:-2].mean() if n > 4 else R.mean()                                # without the two best trades
    stress = R.mean() - (float(np.mean(C)) if C is not None and len(C) else 0.0) > 0         # costs doubled
    pf = pos / neg if neg else 9.9
    half = (R[:n // 2].mean(), R[n // 2:].mean())
    st = dict(n=n, win=(R > 0).mean(), avg=R.mean(), pf=pf, dd=dd, conf=conf, folds=int(sum(f > 0 for f in folds)), half=half)
    checks = [
        (n >= MIN_TRADES, f"only {n} trades, I need {MIN_TRADES}"),
        (st["avg"] >= MIN_EXPECTANCY, f"average {st['avg']:+.2f} R per trade, I need {MIN_EXPECTANCY:+.2f}"),
        (pf >= MIN_PF, f"profit factor {pf:.2f}, I need {MIN_PF:.2f}"),
        (conf >= MIN_CONF, f"only {conf * 100:.0f} percent confidence the edge is real, I need {MIN_CONF * 100:.0f}"),
        (st["folds"] >= 3 and folds[-1] > 0, "the results are not consistent over time, or the most recent period lost money"),
        (trimmed > 0, "it depends on a couple of big winners"),
        (stress, "it does not survive doubled costs"),
        (dd <= MAX_DD_R, f"the worst losing streak, {dd:.1f} R, is too deep"),
    ]
    fail = [msg for ok_, msg in checks if not ok_]
    st["ok"], st["why"] = not fail, (fail[0] if fail else "")
    return st

def backtest(d, cost, strat, inst=None):
    fn, sl_atr, tp_atr = STRATS[strat]
    n, R, C, i = len(d["c"]), [], [], 210
    ts = [_ts(x) for x in d["t"]]
    while i < n - 2:
        s = fn(i, d)
        if (not s or guards.blocked_reason(datetime.fromtimestamp(ts[i] + 3600, TZ), inst)
                or (d["h"][i] - d["l"][i]) > SPIKE_ATR * d["atr"][i - 1]):
            i += 1                                        # only count trades the live rules would allow
            continue
        entry, a = d["c"][i], d["atr"][i]
        risk = sl_atr * a
        sl, tp = entry - s * risk, entry + s * tp_atr * a
        res = None
        for j in range(i + 1, min(i + 120, n)):
            hit_sl = d["l"][j] <= sl if s > 0 else d["h"][j] >= sl
            hit_tp = d["h"][j] >= tp if s > 0 else d["l"][j] <= tp
            if hit_sl:                      # stop assumed first if both hit in one bar (conservative)
                res = -1.0; break
            if hit_tp:
                res = tp_atr / sl_atr; break
        else:
            res = s * (d["c"][j] - entry) / risk
        R.append(res - cost / risk)
        C.append(cost / risk)
        i = j + 1
    return _stats(np.array(R), np.array(C))

# ----------------------------------------------------------------- analysis -> proposal
def analyze_candles(inst, d, live, balance):
    d = indicators(d)
    cost, dec = cost_dec(inst)                # assumed spread + slippage
    name, i = inst.replace("_", " "), len(d["c"]) - 1
    trend = "uptrend" if d["e50"][i] > d["e200"][i] else "downtrend"
    head = f"{name}: {trend}, ADX {d['adx'][i]:.0f}, RSI {d['rsi'][i]:.0f}."
    prev_atr = d["atr"][i - 1]
    if prev_atr > 0 and ((d["h"][i] - d["l"][i]) > SPIKE_ATR * prev_atr or abs(live - d["c"][i]) > 0.8 * SPIKE_ATR * prev_atr):
        return dict(text=f"{head} Price is moving unusually fast, which can mean unscheduled news such as an emergency central-bank move. "
                         "I am standing aside until it calms.", proposal=None, score=-9, spike=True)
    firing = [(nm, STRATS[nm][0](i, d)) for nm in STRATS if nm not in DISABLED]
    firing = [(nm, s) for nm, s in firing if s]
    if not firing:
        return dict(text=f"{head} No setup from any of my five strategies right now.", proposal=None, score=-9)
    cands = []
    for nm, s in firing:                      # backtest only the strategies firing now
        bt = backtest(d, cost, nm, inst)
        cands.append((bt["avg"] if bt["ok"] else -1, nm, s, bt))
    good = [c for c in cands if c[3]["ok"]]
    if not good:
        _, nm, s, bt0 = cands[0]
        return dict(text=f"{head} {nm[0].upper() + nm[1:]} fired a {'buy' if s > 0 else 'sell'} signal, but the backtest does not "
                         f"support it ({bt0['why']}). I would skip it.", proposal=None, score=-1)
    score, nm, s, bt = max(good)
    _, sl_atr, tp_atr = STRATS[nm]
    side, a = ("buy" if s > 0 else "sell"), d["atr"][i]
    stop = sl_atr * a
    sl, tp = live - s * stop, live + s * tp_atr * a
    risk_usd = balance * risk_pct() / 100
    per_unit = stop if inst.endswith("USD") else stop / live       # loss in USD per unit
    units = int(risk_usd / per_unit)
    notional = units * live if inst.endswith("USD") else units
    units = int(units * min(1, balance * MAX_LEVERAGE / notional)) if notional else 0
    if units < 1:
        return dict(text=f"{head} Setup found but the position size is too small to trade.", proposal=None, score=-1)
    prop = dict(inst=inst, units=units * s, entry=live, sl=sl, tp=tp, atr=a, dec=dec, bar=d["t"][i],
                risk=risk_usd, strat=nm)
    text = (f"{head} {nm[0].upper() + nm[1:]} says {side}. Backtest over {len(d['c'])} hourly candles: {bt['n']} trades, "
            f"{bt['win']*100:.0f} percent wins, {bt['avg']:+.2f} R per trade, profit factor {bt['pf']:.1f}, "
            f"worst drawdown {bt['dd']:.1f} R, {bt['conf']*100:.0f} percent confidence the edge is real. Proposal: {side} {units} units at {live:.{dec}f}, "
            f"stop {sl:.{dec}f}, target {tp:.{dec}f}, risking about {risk_usd:.0f} dollars. "
            "Shall I execute? Say yes or no.")
    return dict(text=text, proposal=prop, score=score)

# ----------------------------------------------------------------- 9 AM CR model
def _units(inst, live, stop, balance):
    risk_usd = balance * risk_pct() / 100
    per_unit = stop if inst.endswith("USD") else stop / live
    u = int(risk_usd / per_unit)
    notional = u * live if inst.endswith("USD") else u
    return (int(u * min(1, balance * MAX_LEVERAGE / notional)) if notional else 0), risk_usd

def _cr_short(o, h, l, c, H8, L8, tap, buf):
    """Short-side entry logic. The long side runs the same code on mirrored (negated) prices.
    Needs, while price taps the 8 AM high: an inverse FVG (a bullish gap closed through) AND a bearish order block."""
    n, ifvg, ob = len(c), None, None
    for k in range(tap + 1, min(tap + 61, n)):
        if c[k] < L8:
            return None                                   # target already reached
        if ifvg is None:
            for j in range(max(0, tap - 10), k - 2):      # bullish FVG: low[j+2] > high[j]
                if l[j + 2] > h[j] and c[k] < h[j] and all(c[m] >= h[j] for m in range(j + 3, k)):
                    ifvg = k
                    break
        if ob is None and c[k - 1] > o[k - 1] and c[k] < o[k] and c[k] < o[k - 1]:
            ob = k                                        # down-close beneath the previous up-close
        if ifvg is not None and ob is not None:
            swing = h[tap:k + 1].max()
            entry, sl, tp = c[k], swing + buf, L8
            if swing < H8 or not (sl > entry > tp) or (entry - tp) < (sl - entry):
                return None                               # no sweep, bad geometry, or reward < risk
            return dict(k=k, entry=entry, sl=sl, tp=tp, ifvg=ifvg, ob=ob)
    return None

def cr_find(d):
    """One New-York day of 1-minute bars -> the CR-model trade (or None)."""
    ts = [datetime.fromtimestamp(int(x), TZ) for x in d["t"]]
    mins = np.array([x.hour * 60 + x.minute for x in ts])
    m8 = (mins >= 480) & (mins < 540)
    if m8.sum() < 40:
        return None
    H8, L8 = d["h"][m8].max(), d["l"][m8].min()          # high/low of the 8:00 one-hour candle
    tap, side = None, None
    for i in np.where((mins >= 540) & (mins < 600))[0]:   # the NEXT 1-hour candle (9:00-9:59)
        up, dn = d["h"][i] >= H8, d["l"][i] <= L8
        if up and dn:
            return None
        if up or dn:
            tap, side = i, ("short" if up else "long")
            break
    if tap is None:
        return None
    cut = int(np.where(mins < 720)[0][-1]) + 1            # entries until 12:00
    o, h, l, c = (d[k][:cut] for k in "ohlc")
    buf = 0.01 if np.mean(c) > 20 else 0.0001
    if side == "short":
        r = _cr_short(o, h, l, c, H8, L8, tap, buf)
    else:
        r = _cr_short(-o, -l, -h, -c, -L8, -H8, tap, buf)
        if r:
            r.update(entry=-r["entry"], sl=-r["sl"], tp=-r["tp"])
    if r:
        r.update(side=side, H8=H8, L8=L8, t=int(d["t"][r["k"]]))
    return r

def cr_sim(d, r, cost):
    """R-multiple of one CR trade; stop assumed first if both hit in one bar; flat at 16:00."""
    s = 1 if r["side"] == "long" else -1
    risk = abs(r["entry"] - r["sl"])
    exit_p = d["c"][-1]
    for m in range(r["k"] + 1, len(d["c"])):
        loc = datetime.fromtimestamp(int(d["t"][m]), TZ)
        if loc.hour >= 16:
            exit_p = d["c"][m]; break
        hit_sl = d["l"][m] <= r["sl"] if s > 0 else d["h"][m] >= r["sl"]
        hit_tp = d["h"][m] >= r["tp"] if s > 0 else d["l"][m] <= r["tp"]
        if hit_sl:
            exit_p = r["sl"]; break
        if hit_tp:
            exit_p = r["tp"]; break
    return s * (exit_p - r["entry"]) / risk - cost / risk

def cr_backtest(m, cost, inst=None):
    days = {}
    for i, t in enumerate(m["t"]):
        dt = datetime.fromtimestamp(int(t), TZ)
        if dt.weekday() < 5 and 8 <= dt.hour < 16:
            days.setdefault(dt.date(), []).append(i)
    R, C = [], []
    for _, ix in sorted(days.items()):
        d = {k: m[k][np.array(ix)] for k in "tohlc"}
        r = cr_find(d)
        if r and not guards.blocked_reason(datetime.fromtimestamp(r["t"], TZ), inst):
            R.append(cr_sim(d, r, cost))
            C.append(cost / abs(r["entry"] - r["sl"]))
    return _stats(np.array(R), np.array(C))

def cr_live(b, inst, balance):
    if "9 AM CR model" in DISABLED:
        return None
    now = datetime.now(TZ)
    if now.weekday() >= 5 or not (9 <= now.hour < 12):
        return None                                       # model only trades 9:00-12:00 local market time
    start = int(now.replace(hour=8, minute=0, second=0, microsecond=0).timestamp())
    d = b.m1_since(inst, start)
    if len(d["t"]) < 60:
        return None
    r = cr_find(d)
    if not r or r["k"] < len(d["c"]) - 3:
        return None                                       # confirmation must be fresh
    name = inst.replace("_", " ")
    dec, cost = cost_dec(inst)
    bt = cr_backtest(b.m1_history(inst), cost, inst)
    side = r["side"]
    if not bt["ok"]:
        return dict(text=f"{name}: the 9 AM CR model fired a {'buy' if side == 'long' else 'sell'}, but its backtest "
                         f"({bt['n']} trades, {bt['avg']:+.2f} R each) does not support it ({bt['why']}). I would skip it.",
                    proposal=None, score=-1)
    live, s = d["c"][-1], (1 if side == "long" else -1)
    risk, reward = (live - r["sl"]) * s, (r["tp"] - live) * s
    if risk <= 0 or reward < risk:
        return dict(text=f"{name}: the CR setup has already moved too far to enter safely.", proposal=None, score=-1)
    units, risk_usd = _units(inst, live, risk, balance)
    if units < 1:
        return None
    prop = dict(inst=inst, units=units * s, entry=live, sl=r["sl"], tp=r["tp"], atr=risk, dec=dec,
                bar=str(r["t"]), risk=risk_usd, strat="9 AM CR model")
    word = "buy" if s > 0 else "sell"
    text = (f"{name}: the 9 AM CR model says {word}. The 8 AM range is {r['L8']:.{dec}f} to {r['H8']:.{dec}f}. "
            f"Price swept the {'low' if s > 0 else 'high'} and I see an inverse fair value gap plus an order block on the "
            f"one-minute chart. Backtest over {bt['n']} days: {bt['win']*100:.0f} percent wins, {bt['avg']:+.2f} R per "
            f"trade, profit factor {bt['pf']:.1f}, {bt['conf']*100:.0f} percent confidence the edge is real. Proposal: {word} {units} units at {live:.{dec}f}, stop {r['sl']:.{dec}f}, "
            f"target {r['tp']:.{dec}f}, risking about {risk_usd:.0f} dollars. Shall I execute? Say yes or no.")
    return dict(text=text, proposal=prop, score=bt["avg"])

# ----------------------------------------------------------------- 4 Hour Range strategy
R4_GRAN = os.environ.get("JARVIS_4H_TF", "M5").upper()          # entry timeframe: M5 (default) or M1
R4_START = int(os.environ.get("JARVIS_4H_START", "0"))         # first 4H candle starts at this New York hour (0 = midnight)
R4_TP = os.environ.get("JARVIS_4H_TP", "range").lower()        # "range" = opposite side of the range, "2r" = fixed 1:2
R4_STEP = 1 if R4_GRAN == "M1" else 5                          # minutes per entry bar
R4_MIN_RANGE_PIPS = 10

def r4_find(d):
    """One New-York day of entry-timeframe bars -> the first failed-breakout trade (or None).
    A bar closes OUTSIDE the 4H range, and the very next bar closes back INSIDE it."""
    mins = np.array([x.hour * 60 + x.minute for x in (datetime.fromtimestamp(int(t), TZ) for t in d["t"])])
    a, b = R4_START * 60, R4_START * 60 + 240
    m = (mins >= a) & (mins < b)
    if m.sum() < 0.75 * 240 / R4_STEP:
        return None                                       # first 4H candle missing or not closed yet
    H4, L4 = d["h"][m].max(), d["l"][m].min()
    jpy = np.mean(d["c"]) > 20
    pip = 0.01 if jpy else 0.0001
    if H4 - L4 < R4_MIN_RANGE_PIPS * pip:
        return None                                       # range too tiny to trade
    inside = lambda x: L4 <= x <= H4
    idx = np.where((mins >= b) & (mins < 960))[0]         # entries from the 4H close until 16:00
    for p in range(len(idx) - 1):
        i, k = idx[p], idx[p + 1]
        if i == 0 or k != i + 1 or d["t"][k] - d["t"][i] != R4_STEP * 60 or not inside(d["c"][i - 1]):
            continue
        ci, ck = d["c"][i], d["c"][k]
        if ci > H4 and inside(ck):
            side = "short"
        elif ci < L4 and inside(ck):
            side = "long"
        else:
            continue
        s = -1 if side == "short" else 1
        entry = ck
        extreme = max(d["h"][i], d["h"][k]) if s < 0 else min(d["l"][i], d["l"][k])   # extreme of the failed breakout
        sl = extreme - s * pip * 0.5
        risk = (entry - sl) * s
        tp = entry + s * 2 * risk if R4_TP == "2r" else (L4 if s < 0 else H4)
        if risk <= 0 or (tp - entry) * s < risk:
            continue                                      # bad geometry or reward smaller than risk
        return dict(k=int(k), entry=entry, sl=sl, tp=tp, side=side, H4=H4, L4=L4, t=int(d["t"][k]))
    return None

def r4_backtest(m, cost, inst=None):
    days = {}
    for i, t in enumerate(m["t"]):
        dt = datetime.fromtimestamp(int(t), TZ)
        if dt.weekday() < 5 and R4_START <= dt.hour < 16:
            days.setdefault(dt.date(), []).append(i)
    R, C = [], []
    for _, ix in sorted(days.items()):
        d = {k: m[k][np.array(ix)] for k in "tohlc"}
        r = r4_find(d)
        if r and not guards.blocked_reason(datetime.fromtimestamp(r["t"], TZ), inst):
            R.append(cr_sim(d, r, cost))
            C.append(cost / abs(r["entry"] - r["sl"]))
    return _stats(np.array(R), np.array(C))

def r4_live(b, inst, balance):
    if "4 Hour Range" in DISABLED:
        return None
    now = datetime.now(TZ)
    if now.weekday() >= 5 or not (R4_START + 4 <= now.hour < 16):
        return None                                       # only after the first 4H candle closes, until 16:00 New York
    start = int(now.replace(hour=R4_START, minute=0, second=0, microsecond=0).timestamp())
    d = b.bars_since(inst, start, R4_GRAN)
    if len(d["t"]) < 40:
        return None
    r = r4_find(d)
    if not r or r["k"] < len(d["c"]) - 2:
        return None                                       # confirmation must be fresh
    name = inst.replace("_", " ")
    dec, cost = cost_dec(inst)
    bt = r4_backtest(b.bars_history(inst, R4_GRAN), cost, inst)
    s = 1 if r["side"] == "long" else -1
    word = "buy" if s > 0 else "sell"
    if not bt["ok"]:
        return dict(text=f"{name}: the 4 Hour Range strategy fired a {word}, but its backtest ({bt['n']} trades, "
                         f"{bt['avg']:+.2f} R each) does not support it ({bt['why']}). I would skip it.", proposal=None, score=-1)
    live = d["c"][-1]
    risk, reward = (live - r["sl"]) * s, (r["tp"] - live) * s
    if risk <= 0 or reward < risk:
        return dict(text=f"{name}: the 4 Hour Range setup has already moved too far to enter safely.", proposal=None, score=-1)
    units, risk_usd = _units(inst, live, risk, balance)
    if units < 1:
        return None
    prop = dict(inst=inst, units=units * s, entry=live, sl=r["sl"], tp=r["tp"], atr=risk, dec=dec,
                bar=str(r["t"]), risk=risk_usd, strat="4 Hour Range")
    text = (f"{name}: the 4 Hour Range strategy says {word}. The range is {r['L4']:.{dec}f} to {r['H4']:.{dec}f}. "
            f"A candle closed {'below the low' if s > 0 else 'above the high'} and the next one closed back inside, a failed breakout. "
            f"Backtest over {bt['n']} days: {bt['win']*100:.0f} percent wins, {bt['avg']:+.2f} R per trade, profit factor "
            f"{bt['pf']:.1f}, {bt['conf']*100:.0f} percent confidence the edge is real. Proposal: {word} {units} units at {live:.{dec}f}, stop {r['sl']:.{dec}f}, target {r['tp']:.{dec}f}, "
            f"risking about {risk_usd:.0f} dollars. Shall I execute? Say yes or no.")
    return dict(text=text, proposal=prop, score=bt["avg"])

def scan_context():
    """The checks done ONCE per scan (kill switch, hours, account, daily loss, open trades). Returns (context, None), or (None, finished result)."""
    if killed():
        return None, dict(text="The kill switch is active, so I am not scanning or trading.", proposal=None, halt=True)
    why = guards.blocked_reason()
    if why:
        return None, dict(text=f"Standing by: {why}.", proposal=None)
    b = broker()
    balance, ccy, _ = b.summary()
    if ccy != "USD":
        return None, dict(text="The account must be in US dollars for my position sizing.", proposal=None)
    stop = daily_guard(b)
    if stop:
        return None, dict(text=stop, proposal=None, halt=True)
    held = b.open_instruments()
    if len(held) >= MAX_OPEN:
        return None, dict(text=f"I already have {len(held)} open trades, which is my limit. Standing by.", proposal=None)
    return dict(b=b, balance=balance, held=held, held_pos=b.open_positions()), None


def scan_pair(ctx, inst):
    """All the analysis for ONE pair: pure reading, safe to run in parallel (the manager's workers call this). Returns result dicts."""
    b, balance = ctx["b"], ctx["balance"]
    if inst in ctx["held"]:
        return []
    why = guards.blocked_reason(inst=inst)                 # this pair's own central bank / US data
    if why:
        return [dict(text=f"{inst.replace('_', ' ')}: standing by, {why}.", proposal=None, score=-9)]
    d, live = b.candles(inst)
    out = [analyze_candles(inst, d, live, balance)]
    if out[0].get("spike"):
        return out                                         # unusual volatility: skip every strategy on this pair
    for model, fn in (("CR model", cr_live), ("4 Hour Range", r4_live)):
        try:
            extra = fn(b, inst, balance)
            if extra:
                out.append(extra)
        except Exception as e:
            print(model, "error:", e)
    return out


def choose(results, ctx, pairs):
    """Turn the per-pair results into one answer: drop stacked exposure, then pick the best-evidenced setup."""
    if not results:
        return dict(text="You already hold a position in that pair, so I will not stack another.", proposal=None)
    props = []
    for r in results:                                     # never stack the same-direction exposure to one currency
        p = r["proposal"]
        if not p:
            continue
        cur = guards.exposure_conflict(ctx["held_pos"], p["inst"], 1 if p["units"] > 0 else -1)
        if cur:
            r["proposal"] = None
            r["text"] = r["text"].replace(" Shall I execute? Say yes or no.", "") + f" I already hold {cur} exposure in that direction, so I am skipping it."
        else:
            props.append(r)
    if props:
        best = max(props, key=lambda r: r["score"])
        return dict(text=best["text"], proposal=best["proposal"])
    if len(pairs) == 1:
        return dict(text=" ".join(r["text"] for r in results), proposal=None)
    return dict(text="I scanned the majors with all seven strategies and found no setup the backtest supports. Standing by.", proposal=None)


def scan(pairs):
    """Single-threaded scan (one manager, no workers): the same steps the workers share out."""
    ctx, early = scan_context()
    if early is not None:
        return early
    results = []
    for inst in pairs:
        results += scan_pair(ctx, inst)
    return choose(results, ctx, pairs)


class ReadOnly:
    """The broker view handed to workers: it can read prices and positions but has no way to place, move or close an order."""
    READ = {"candles", "bars_since", "bars_history", "m1_since", "m1_history", "summary", "equity", "open_instruments",
            "open_positions", "spread", "closed_trades", "env", "acct"}

    def __init__(self, b):
        self._b = b

    def __getattr__(self, name):
        if name in ReadOnly.READ:
            return getattr(self._b, name)
        raise PermissionError(f"workers can only read: '{name}' is not allowed")


# ----------------------------------------------------------------- execution (only after "yes")
def execute(p):
    if killed():
        return "The kill switch is active, so I will not place any trades."
    today = time.strftime("%Y-%m-%d")
    if _trades_today["day"] != today:
        _trades_today.update(day=today, n=0)
    if _trades_today["n"] >= MAX_TRADES_PER_DAY:
        return f"Daily limit of {MAX_TRADES_PER_DAY} trades reached. I will not place another today."
    b = broker()
    stop = daily_guard(b)
    if stop:
        return stop
    why = guards.blocked_reason(inst=p["inst"])
    if why:
        return f"I will not place it now: {why}."
    _, live = b.candles(p["inst"])
    if abs(live - p["entry"]) > SLIPPAGE_ATR * p["atr"]:
        return "Price has moved too far since my proposal, so I aborted. Ask me to scan again."
    try:
        sp = b.spread(p["inst"])
    except Exception:
        sp = 0.0
    if guards.spread_too_wide(sp, abs(p["entry"] - p["sl"])):
        return f"The spread is {sp:.5g} against a stop of {abs(p['entry'] - p['sl']):.5g}, too wide to trade now. Nothing was placed."
    r = b.order(p["inst"], p["units"], p["sl"], p["tp"], p["dec"], p.get("strat", ""))
    if "orderFillTransaction" in r:
        f = r["orderFillTransaction"]
        _trades_today["n"] += 1
        return (f"Done. Filled {abs(p['units'])} units of {p['inst'].replace('_', ' ')} at {float(f['price']):.{p['dec']}f} "
                f"on the {b.env} account, with stop loss and take profit attached.")
    why = r.get("orderCancelTransaction", {}).get("reason", "unknown reason")
    return f"The broker did not fill the order: {why}. Nothing was placed."
