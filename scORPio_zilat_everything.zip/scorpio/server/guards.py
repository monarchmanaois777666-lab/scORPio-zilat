"""
guards.py - extra safety rules applied before any trade, by Jarvis and by his manager.

1. Session and news filter: weekdays only, set hours (New York time), no new trades late on Friday, and blackouts around
   scheduled news: Fed, US jobs report, US CPI, ECB, Bank of England, Bank of Canada, SNB (+ anything in blackouts.txt).
   A US event pauses every pair; a currency's own central bank pauses only the pairs that contain that currency.
   (The RBA, RBNZ and BoJ announce before 02:00 New York time, outside my trading hours, so I never open trades near them.)
2. Currency exposure: never stack the same-direction exposure to one currency (two "short USD" trades count as one bet).
3. Spread check helper.
Unscheduled news (for example an emergency central-bank meeting) cannot be on a calendar. trader.py handles it with a
volatility circuit breaker: after a sudden spike in price movement I stand aside until it calms.
Turn the time/news filter off with JARVIS_GUARDS=off. Hours: JARVIS_HOURS=2-15 (New York). Exposure: JARVIS_MAX_CCY_EXPOSURE=1.
"""
import os, re, sys
from datetime import datetime, timedelta, timezone
try:
    from zoneinfo import ZoneInfo
    TZ = ZoneInfo(os.environ.get("JARVIS_TZ", "America/New_York"))
except Exception:
    ZoneInfo = None
    TZ = timezone(timedelta(hours=-5))

# ---- Official calendars (sources: federalreserve.gov, bls.gov, ecb.europa.eu, bankofengland.co.uk, bankofcanada.ca, snb.ch) ----
# Dates are decision/release days; "at" is the local time of the announcement. Anything after a calendar's "known" range falls back to a
# wider recurring window on the weekday that event always uses (see blackouts()), so a missing date never leaves you unprotected.
FOMC = [
    "2024-01-31", "2024-03-20", "2024-05-01", "2024-06-12", "2024-07-31", "2024-09-18", "2024-11-07", "2024-12-18",
    "2025-01-29", "2025-03-19", "2025-05-07", "2025-06-18", "2025-07-30", "2025-09-17", "2025-10-29", "2025-12-10",
    "2026-01-28", "2026-03-18", "2026-04-29", "2026-06-17", "2026-07-29", "2026-09-16", "2026-10-28", "2026-12-09",
    "2027-01-27", "2027-03-17", "2027-04-28", "2027-06-09", "2027-07-28", "2027-09-15", "2027-10-27", "2027-12-08",
    "2028-01-26",
]
NFP = ["2026-01-09", "2026-02-11", "2026-03-06", "2026-04-03", "2026-05-08", "2026-06-05",
       "2026-07-02", "2026-08-07", "2026-09-04", "2026-10-02", "2026-11-06", "2026-12-04"]
CPI = ["2025-12-18", "2026-01-13", "2026-02-13", "2026-03-11", "2026-04-10", "2026-05-12", "2026-06-10",
       "2026-07-14", "2026-08-12", "2026-09-11", "2026-10-14", "2026-11-10", "2026-12-10"]
ECB = ["2025-01-30", "2025-03-06", "2025-04-17", "2025-06-05", "2025-07-24", "2025-09-11", "2025-10-30", "2025-12-18",
       "2026-02-05", "2026-03-19", "2026-04-30", "2026-06-11", "2026-07-23", "2026-09-10", "2026-10-29", "2026-12-17",
       "2027-02-04", "2027-03-18", "2027-04-29"]
BOE = ["2025-02-06", "2025-03-20", "2025-05-08", "2025-06-19", "2025-08-07", "2025-09-18", "2025-11-06", "2025-12-18",
       "2026-02-05", "2026-03-19", "2026-04-30", "2026-06-18", "2026-07-30", "2026-09-17", "2026-11-05", "2026-12-17",
       "2027-02-04", "2027-03-18", "2027-04-29", "2027-06-17", "2027-07-29", "2027-09-16", "2027-11-04", "2027-12-16"]
BOC = ["2026-09-02", "2026-10-28", "2026-12-09",
       "2027-01-27", "2027-03-03", "2027-04-28", "2027-06-02", "2027-07-21", "2027-09-08", "2027-10-27", "2027-12-08"]
SNB = ["2025-03-20", "2025-06-19", "2025-09-25", "2025-12-11", "2026-03-19", "2026-06-18", "2026-09-24", "2026-12-10",
       "2027-03-18", "2027-06-24", "2027-09-23", "2027-12-16"]

NY = "America/New_York"
EVENTS = {
    "FOMC": dict(name="Fed rate decision", ccy="USD", tz=NY, at="14:00", fb=(2,), dates=FOMC, known=("2024-01-01", "2028-01-31")),
    "NFP": dict(name="US jobs report", ccy="USD", tz=NY, at="08:30", fb=(3, 4), dates=NFP, known=("2026-01-01", "2026-12-31")),
    "CPI": dict(name="US CPI", ccy="USD", tz=NY, at="08:30", fb=(0, 1, 2, 3, 4), dom=(9, 16), dates=CPI, known=("2025-12-01", "2026-12-31")),
    "ECB": dict(name="ECB rate decision", ccy="EUR", tz="Europe/Berlin", at="14:15", fb=(3,), dates=ECB, known=("2025-01-01", "2027-04-30")),
    "BOE": dict(name="Bank of England rate decision", ccy="GBP", tz="Europe/London", at="12:00", fb=(3,), dates=BOE, known=("2025-01-01", "2027-12-31")),
    "BOC": dict(name="Bank of Canada rate decision", ccy="CAD", tz="America/Toronto", at="09:45", fb=(2,), dates=BOC, known=("2026-09-01", "2027-12-31")),
    "SNB": dict(name="SNB rate decision", ccy="CHF", tz="Europe/Zurich", at="09:30", fb=(3,), dates=SNB, known=("2025-01-01", "2027-12-31")),
}


def _base():
    return os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))


def _tz(name):
    try:
        return ZoneInfo(name) if ZoneInfo else TZ
    except Exception:
        return TZ


def _hours():
    m = re.match(r"^\s*(\d{1,2})\s*-\s*(\d{1,2})\s*$", os.environ.get("JARVIS_HOURS", "2-15"))
    return (int(m.group(1)), int(m.group(2))) if m else (2, 15)


def _at(date_str, hhmm, tz=None):
    h, m = hhmm.split(":")
    return datetime.strptime(date_str, "%Y-%m-%d").replace(hour=int(h), minute=int(m), tzinfo=tz or TZ)


def _user_lines():
    path = os.environ.get("JARVIS_BLACKOUTS") or os.path.join(_base(), "blackouts.txt")
    if os.path.exists(path):
        for line in open(path, encoding="utf-8"):
            line = line.split("#")[0].strip()
            if line:
                yield line


def _calendar():
    """{key: (dates, covered-through)} including what you add to blackouts.txt: 'ECB 2027-06-10', 'ECB-THROUGH 2027-12-31', ..."""
    cal = {k: [set(v["dates"]), v["known"][1]] for k, v in EVENTS.items()}
    for line in _user_lines():
        p = line.split()
        if len(p) == 2 and re.match(r"^\d{4}-\d{2}-\d{2}$", p[1]):
            key = p[0].upper()
            if key in cal:
                cal[key][0].add(p[1])
            elif key.endswith("-THROUGH") and key[:-8] in cal:
                cal[key[:-8]][1] = max(cal[key[:-8]][1], p[1])
    return {k: (v[0], v[1]) for k, v in cal.items()}


def blackouts(now, ccys=("USD",)):
    """(start, end, note) windows for this day for events that move the given currencies, plus your own events.
    Window: 30 minutes before to 60 minutes after the announcement."""
    out, day, cal = [], now.strftime("%Y-%m-%d"), _calendar()
    for key, ev in EVENTS.items():
        if ev["ccy"] not in ccys:
            continue
        dates, through = cal[key]
        tz = _tz(ev["tz"])
        if day in dates:
            t = _at(day, ev["at"], tz)
            out.append((t - timedelta(minutes=30), t + timedelta(minutes=60), ev["name"]))
        elif (not (ev["known"][0] <= day <= through) and now.weekday() in ev["fb"]
              and (not ev.get("dom") or ev["dom"][0] <= now.day <= ev["dom"][1])):
            t = _at(day, ev["at"], tz)                                   # calendar not published here: block the usual weekday
            out.append((t - timedelta(minutes=30), t + timedelta(minutes=60), f"possible {ev['name']} (calendar not published for this date)"))
    for line in _user_lines():                                           # 2026-11-10 08:30, 30, 60, my own event
        parts = [x.strip() for x in line.split(",")]
        try:
            d, hhmm = parts[0].split()
            if d == day:
                t = _at(d, hhmm)
                out.append((t - timedelta(minutes=int(parts[1])), t + timedelta(minutes=int(parts[2])), parts[3] if len(parts) > 3 else "news"))
        except Exception:
            continue
    return out


def blocked_reason(now=None, inst=None):
    """Why new trades are not allowed right now, or None. With inst, that pair's own currencies' events count too."""
    if os.environ.get("JARVIS_GUARDS", "").lower() == "off":
        return None
    now = (now or datetime.now(TZ)).astimezone(TZ)
    if now.weekday() >= 5:
        return "the forex market is closed at the weekend"
    lo, hi = _hours()
    h = now.hour + now.minute / 60
    if not (lo <= h < hi):
        return f"it is outside my trading hours ({lo}:00 to {hi}:00 New York time)"
    if now.weekday() == 4 and h >= 12:
        return "it is late on a Friday, so I avoid new trades before the weekend"
    ccys = {"USD"} if inst is None else set(inst.split("_"))
    for start, end, note in blackouts(now, tuple(ccys)):
        if start <= now < end:
            return f"news blackout for the {note}"
    return None


def currency_exposure(positions):
    net = {}
    for p in positions:
        base, quote = p["inst"].split("_")
        net[base] = net.get(base, 0) + p["side"]
        net[quote] = net.get(quote, 0) - p["side"]
    return net


def exposure_conflict(positions, inst, side):
    """The currency that would be stacked in the same direction, or None."""
    try:
        limit = float(os.environ.get("JARVIS_MAX_CCY_EXPOSURE", "1"))
    except ValueError:
        limit = 1.0
    net, (base, quote) = currency_exposure(positions), inst.split("_")
    for cur, direction in ((base, side), (quote, -side)):
        if net.get(cur, 0) * direction >= limit:
            return cur
    return None


def spread_too_wide(spread, stop_distance, frac=0.15):
    return bool(stop_distance) and spread > frac * stop_distance
