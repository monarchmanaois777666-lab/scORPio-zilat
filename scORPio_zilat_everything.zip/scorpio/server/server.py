#!/usr/bin/env python3
"""
scORPio zilat - phone server.
Runs on your computer / Raspberry Pi / VPS. The phone app talks to it, and your broker keys never leave this machine.

    python server.py          # reachable from this computer only
    python server.py --lan    # also reachable from your phone on the same Wi-Fi

Every API call needs your access token (printed at start). Trades still need a YES from you.
"""
import os, sys, json, time, hmac, secrets, socket, threading, re, mimetypes, shutil, subprocess
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import brain            # loads .env, forex knowledge, optional Claude answers
import trader
import agent            # the manager Jarvis directs
import memory           # Jarvis's long-term memory

HERE = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))   # where .env and the token live
ROOT = os.path.join(getattr(sys, "_MEIPASS", HERE), "app")                                                              # the bundled phone app
TTL = 120               # seconds a trade proposal stays valid

def get_token():
    t = os.environ.get("SCORPIO_TOKEN")
    if t:
        return t
    p = os.path.join(HERE, ".scorpio_token")
    if os.path.exists(p):
        return open(p).read().strip()
    t = secrets.token_urlsafe(12)
    open(p, "w").write(t)
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
    return t

TOKEN = get_token()
FAILS = []              # recent wrong-token attempts (the public link must not be guessable)
TUNNEL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")

def locked():
    now = time.time()
    FAILS[:] = [t for t in FAILS if now - t < 60]
    return len(FAILS) >= 5


def start_tunnel(port):
    """--share: open a free Cloudflare quick tunnel so the app gets its own https link (mic works, installable)."""
    local = os.path.join(HERE, "cloudflared.exe")
    exe = shutil.which("cloudflared") or (local if os.path.exists(local) else None)
    if not exe:
        return None, None, ("cloudflared is not installed. Get it free from "
                            "https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/ and run again.")
    proc = subprocess.Popen([exe, "tunnel", "--url", f"http://localhost:{port}", "--no-autoupdate"],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    found, got = {}, threading.Event()

    def reader():
        for line in proc.stdout:                          # keeps draining so the tunnel never blocks
            m = TUNNEL_RE.search(line)
            if m and "url" not in found:
                found["url"] = m.group(0)
                got.set()
    threading.Thread(target=reader, daemon=True).start()
    got.wait(45)
    return found.get("url"), proc, (None if found.get("url") else "The tunnel did not start in time.")
YES = re.compile(r"\b(yes|yeah|yep|yup|execute|confirm|confirmed|go ahead|do it|place it|proceed)\b")
NO = re.compile(r"\b(no|nope|cancel|stop|abort|don'?t|negative|never ?mind|reject|skip)\b")


class Session:
    """JARVIS, the boss. He understands your orders, speaks, asks for your approval, and directs the manager,
    who does the work. The manager reports to him and he reports to you."""
    STRAT_WORDS = [(r"pullback", "trend pullback"), (r"break.?out|channel", "channel breakout"),
                   (r"range reversion|mean reversion", "range reversion"), (r"macd", "MACD momentum"),
                   (r"support reversal|reversal", "support reversal"), (r"cr model|9 ?am", "9 AM CR model"),
                   (r"4 ?h(our)? range|four.?hour range", "4 Hour Range")]

    def __init__(self):
        self.pending, self.ap_ask, self.ca_ask = None, False, False
        self.events = []
        self.lock = threading.Lock()
        self.mgr = agent.Manager(self._report)
        self.mem = memory.Memory()
        brain.memory_context = self.mem.context
        brain.HISTORY[:] = self.mem.recent(24)            # the conversation survives a restart
        while brain.HISTORY and brain.HISTORY[-1]["role"] == "user":
            brain.HISTORY.pop()
        self.last_intent = None

    @property
    def watching(self):
        return self.mgr.working

    @property
    def autopilot(self):
        return self.mgr.mode == "auto"

    def _report(self, kind, text, prop=None):             # the manager reports to the boss
        self.mem.log("event", "manager", text)
        with self.lock:
            if kind == "proposal":
                if self.pending and time.time() - self.pending["t"] > TTL:
                    self.pending = None
                if self.pending is not None or not prop:
                    return False
                self.pending = {"prop": prop, "t": time.time()}
                self.events.append(dict(reply=text, pending=True))
            else:
                self.events.append(dict(reply=text, pending=False))
            return True

    def chat(self, q):
        q = q.strip()[:300]
        if not q:
            return dict(reply="I did not catch that.", pending=bool(self.pending), confirm="")
        with self.lock:                                   # one request at a time: no double execution
            try:
                self.mem.observe(q)
                reply = self.mem.handle(q)
                if reply is None:
                    reply = self._route(q)
            except Exception as e:
                reply = "I hit a problem: " + str(e)[:140]
            reply = brain.personalize(reply, self.mem.address)
            self.mem.note_exchange(q, reply)
            brain.HISTORY.extend([{"role": "user", "content": q}, {"role": "assistant", "content": reply}])   # the AI sees every turn
            del brain.HISTORY[:-40]
            self.mem.log("chat", "user", q)
            self.mem.log("chat", "jarvis", reply)
            return dict(reply=reply, pending=bool(self.pending),
                        confirm="confirm autopilot" if self.ap_ask else "confirm close all" if self.ca_ask
                        else "confirm forget everything" if self.mem.pending_forget else "")

    def _route(self, q):
        s = q.lower()
        asked, self.ap_ask = self.ap_ask, False
        closing, self.ca_ask = self.ca_ask, False
        fu = re.match(r"^\s*(?:ok(?:ay)?,?\s+)?(?:and|what about|how about)\s+(.+?)\s*\??\s*$", q, re.I)
        if fu and self.last_intent:                       # a follow-up such as "and gold?" or "what about MACD?"
            rest = fu.group(1)
            if self.last_intent == "scan" and trader.find_pairs(rest):
                return self._route("scan " + rest)
            hit = self.mgr.playbook.lookup(rest)
            if hit:
                return hit
            if os.environ.get("ANTHROPIC_API_KEY"):
                return brain.ask(q)                       # the AI has the conversation history
            return "I can follow up on pairs after a scan, or on topics I know. Add an Anthropic key to my server and I can follow any thread."
        if re.search(r"(activate|engage|hit|pull|trigger|press)\b.*kill.?switch|emergency stop|kill.?switch\b.*\b(on|activate)", s):
            open(trader.KILL_FILE, "w").write("stopped by the boss\n")
            self.mgr.stop()
            self.mgr.set_mode("propose")
            self.pending = None
            return "Kill switch activated. My manager has stopped, and nobody can place a trade until you release it."
        if re.search(r"(release|clear|remove|deactivate|lift)\b.*kill.?switch|kill.?switch\b.*\b(off|release)", s):
            if os.path.exists(trader.KILL_FILE):
                os.remove(trader.KILL_FILE)
            return "Kill switch released. Tell me to start work when you are ready."
        if closing and re.search(r"confirm close all|yes close all", s):
            return self._close_all()
        if re.search(r"\b(close|flatten|exit)\b.*\b(all|everything)\b|\bpanic\b", s):
            if not trader.configured():
                return trader.SETUP_HELP
            ours = [p for p in trader.broker().open_positions() if p.get("ours")]
            if not ours:
                return "I have no open trades of my own to close."
            self.ca_ask = True
            return (f"Warning, sir. This closes all {len(ours)} open trades I placed, at the market price, and stops my manager. "
                    "It does not touch trades you opened yourself. Say confirm close all.")
        if re.search(r"\b(open (trades|positions)|what'?s open|my positions|my open)\b", s):
            if not trader.configured():
                return trader.SETUP_HELP
            return self._open_report()
        if re.search(r"export.*(journal|trades)|journal.*export", s):
            n = self.mgr.ledger.export(os.path.join(HERE, "journal.csv"))
            return f"Saved {n} closed trades to journal.csv next to the server."
        if re.search(r"\b(stop|disable|turn off|kill|cancel)\b.*\bauto.?(pilot|trad\w*)|\bauto.?(pilot|trad\w*)\b.*\b(off|disable|stop)\b", s):
            self.mgr.set_mode("propose")
            return "Autopilot is off. My manager will propose trades and I will wait for your yes."
        if re.search(r"\bauto.?(pilot|trad\w*)\b", s) and re.search(r"\b(on|enable|start|activate|engage)\b|confirm", s):
            return self._autopilot_on(asked and "confirm" in s)
        if re.search(r"\b(stop|pause|end)\b.*\bwork\b|\btake a break\b|stop (watching|monitoring|scanning|trading)|\bmanager\b.*\b(stop|rest|pause)\b", s):
            self.mgr.stop()
            self.mgr.set_mode("propose")
            return "Understood. I have told my manager to stop work. She is back in proposal mode."
        if re.search(r"\b(start|begin|resume|go)\b.*\bwork\b|\bget to work\b|\b(put|send) (the |her )?(manager|agent|her)?\s*to work\b|\bwake (up )?(the )?(manager|agent)\b|"
                     r"\bwatch\b.*\b(market|forex|pairs|majors)\b|start (watching|scanning|trading)|auto ?scan", s):
            if not trader.configured():
                return trader.SETUP_HELP
            if not self.mgr.start():
                return "The kill switch is active, so I cannot send my manager to work. Tell me to release it first."
            st = self.mgr.status()
            return ("Understood. I have told my manager to start work. She will scan the majors every five minutes and report to me. "
                    + ("She is on autopilot." if st["mode"] == "auto" else "She is in proposal mode, so I will ask you before any trade."))
        m = re.search(r"\b(?:use|set|run with|limit(?: to)?)\s+(\d+|one|two|three|four|five|six|seven|eight)\s+workers?\b|\bworkers?\s+(?:to|limit)\s+(\d+)\b", s)
        if m:
            words = dict(one=1, two=2, three=3, four=4, five=5, six=6, seven=7, eight=8)
            raw = m.group(1) or m.group(2)
            n = self.mgr.set_worker_limit(words.get(raw, raw))
            wanted = int(words.get(raw, raw))
            return (f"Understood. My manager will use up to {n} worker{'s' if n != 1 else ''} at once." if wanted <= 8
                    else f"The maximum is 8, so my manager will use 8 workers at once, not {wanted}.")
        if re.search(r"\bhow many workers\b|\b(show|list)\b.*\b(workers|team|crew)\b|\bwho is working\b|\bworker status\b", s):
            return self.mgr.workers_report()
        if re.search(r"\b(report|briefing)\b|how (is|are) (she|the manager|we|you|it) doing|how am i doing|my (results|performance|stats)|performance report|status report", s):
            return "I asked my manager. " + self.mgr.briefing()
        if re.search(r"what (does|do|did) (the manager|she|you) (know|learn)|what have you taught|manager.*(know|learn)", s):
            return self.mgr.playbook.summary()
        if re.search(r"reset (the )?(drawdown|peak)", s):
            self.mgr.reset_peak()
            return "Done. I have reset my equity peak, and my manager is back to full risk."
        if re.search(r"\b(reset focus|all pairs|trade everything|trade all)\b", s):
            self.mgr.focus(reset=True)
            return "Understood. My manager will watch every major pair and use every strategy."
        if re.search(r"\b(focus|only|just)\b.*\b(trade|trading|on)\b|\btrade only\b", s):
            pairs = trader.find_pairs(s)
            strats = [name for pat, name in self.STRAT_WORDS if re.search(pat, s)]
            if pairs or strats:
                self.mgr.focus(pairs=pairs or None, strategies=strats or None)
                bits = ([", ".join(p.replace("_", " ") for p in pairs)] if pairs else []) + (strats or [])
                return "Understood. I have told my manager to focus on " + " using ".join(bits) + "."
        if self.pending:                                  # waiting for the user's decision
            p = self.pending
            if NO.search(s):
                self.pending = None
                return "Understood, sir. Cancelled. Nothing was placed."
            if YES.search(s):
                self.pending = None
                if time.time() - p["t"] > TTL:
                    return "That proposal expired because prices move. Ask me to scan again."
                return trader.execute(p["prop"])
        pair = trader.find_pair(s)
        if (re.search(r"\b(analy[sz]e|scan)\b|any (trades?|setups?|opportunit)|should i (buy|sell)|trade now|find me a (trade|setup)", s)
                or (pair and re.search(r"\b(trend|buy|sell|check|look)\b", s))):
            if not trader.configured():
                return trader.SETUP_HELP
            self.last_intent = "scan"
            res = trader.scan([pair] if pair else trader.universe())
            if res["proposal"]:
                self.pending = {"prop": res["proposal"], "t": time.time()}
            return res["text"]
        self.last_intent = "ask"
        return brain.ask(q)

    def _open_report(self):
        pos = trader.broker().open_positions()
        if not pos:
            return "You have no open trades."
        parts = [f"{p['inst'].replace('_', ' ')} {'buy' if p['side'] > 0 else 'sell'} {p['units']:g} units, {p['pl']:+.2f} dollars" for p in pos]
        return f"You have {len(pos)} open trades: " + "; ".join(parts) + "."

    def _close_all(self):
        self.mgr.stop()
        self.mgr.set_mode("propose")
        self.pending = None
        b = trader.broker()
        ours = [p for p in b.open_positions() if p.get("ours")]
        done = sum(1 for p in ours if b.close_position(p))
        return (f"Closed {done} of {len(ours)} trades and stopped my manager."
                + ("" if done == len(ours) else " Some did not close, so check your platform now."))

    def _autopilot_on(self, confirmed):
        if os.environ.get("JARVIS_AUTOPILOT_ALLOWED") != "1":
            return "Autopilot is locked. Set JARVIS_AUTOPILOT_ALLOWED=1 in the server's .env file to allow it."
        if not trader.configured():
            return trader.SETUP_HELP
        if trader.killed():
            return "The kill switch is active. Tell me to release it first."
        mode = trader.broker_mode()
        if mode != "practice" and not confirmed:
            self.ap_ask = True
            return ("Warning, sir. This is a REAL-money account. On autopilot my manager places trades without asking, "
                    f"risking {trader.risk_pct():g} percent each, up to {trader.MAX_TRADES_PER_DAY} a day, and she stops at a "
                    f"{trader.MAX_DAILY_LOSS_PCT:g} percent daily loss. Say confirm autopilot to authorise her.")
        self.mgr.set_mode("auto")
        self.mgr.start()
        return ("I have authorised my manager to trade autopilot" + (" on your REAL account" if mode != "practice" else " on your practice account")
                + ". She reports every trade to me. Say stop autopilot at any time.")

    def set_watch(self, on):
        if on:
            self.mgr.start()
        else:
            self.mgr.stop()
            self.mgr.set_mode("propose")

    def poll(self):
        with self.lock:
            ev, self.events = self.events, []
        for e in ev:
            e["reply"] = brain.personalize(e["reply"], self.mem.address)
        return ev

    def status(self):
        return dict(configured=trader.configured(), mode=trader.broker_mode(), watching=self.watching,
                    pending=bool(self.pending), autopilot=self.autopilot, tier=self.mgr.tier,
                    broker=os.environ.get("JARVIS_BROKER", "oanda").lower(), manager=self.mgr.status(), name=self.mem.p["name"])

S = Session()


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json"):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "X-Token, Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(b)

    def _auth(self):
        if locked():
            self._send(429, {"error": "too many wrong tokens, wait a minute"})
            return False
        if hmac.compare_digest(self.headers.get("X-Token", "").encode(), TOKEN.encode()):
            return True
        FAILS.append(time.time())
        time.sleep(1)                                     # slow down guessing
        self._send(401, {"error": "unauthorized"})
        return False

    def do_OPTIONS(self):
        self._send(204, b"", "text/plain")

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/health":                         # no secrets: lets the app confirm an address really is this server
            self._send(200, {"app": "scorpio-zilat", "ok": True})
        elif path == "/api/status":
            if self._auth():
                self._send(200, S.status())
        elif path == "/api/poll":
            if self._auth():
                self._send(200, {"events": S.poll()})
        elif path.startswith("/api/"):
            self._send(404, {"error": "not found"})
        else:                                             # the phone app itself (no secrets in it)
            rel = "index.html" if path == "/" else os.path.normpath(path.lstrip("/"))
            full = os.path.realpath(os.path.join(ROOT, rel))
            if not full.startswith(os.path.realpath(ROOT) + os.sep) or not os.path.isfile(full):
                return self._send(404, b"not found", "text/plain")
            ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
            self._send(200, open(full, "rb").read(), ctype)

    def do_POST(self):
        path = urlparse(self.path).path
        if not self._auth():
            return
        try:
            n = int(self.headers.get("Content-Length", 0))
            data = json.loads(self.rfile.read(min(n, 4096)) or b"{}")
        except Exception:
            return self._send(400, {"error": "bad request"})
        if path == "/api/chat":
            self._send(200, S.chat(str(data.get("text", ""))))
        elif path == "/api/watch":
            S.set_watch(bool(data.get("on")))
            self._send(200, S.status())
        else:
            self._send(404, {"error": "not found"})


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except Exception:
        return "your-computer-ip"


def main():
    if getattr(sys, "frozen", False) and len(sys.argv) == 1:
        sys.argv += ["--lan", "--share"]                  # double-clicked .exe: do the sensible thing
    lan = "--lan" in sys.argv
    port = int(os.environ.get("PORT", 8765))
    srv = ThreadingHTTPServer(("0.0.0.0" if lan else "127.0.0.1", port), H)
    share_url, tunnel, tunnel_err = (None, None, None)
    if "--share" in sys.argv:
        print("\n  Starting your private https link (can take ~10 seconds)...")
        share_url, tunnel, tunnel_err = start_tunnel(port)
    print("\n  scORPio zilat server")
    print("  Open on this computer :", f"http://localhost:{port}")
    if lan:
        print("  Same Wi-Fi (no mic)   :", f"http://{lan_ip()}:{port}/#t={TOKEN}")
    if share_url:
        print("\n  >>> YOUR APP LINK (open on your phone, then Add to Home Screen) <<<")
        print("     ", f"{share_url}/#t={TOKEN}")
        print("      Keep this link secret: it logs you in. It works while this server and tunnel keep running.\n")
    elif tunnel_err:
        print("  Share link            :", tunnel_err)
    print("  Access token          :", TOKEN)
    print("  Broker                :", (os.environ.get("JARVIS_BROKER", "oanda").upper() + " (account type is checked on first use)")
          if trader.configured() else "not configured (answers only, no trading)")
    print("  Autopilot             :", "allowed (still needs your confirmation in the app)"
          if os.environ.get("JARVIS_AUTOPILOT_ALLOWED") == "1" else "locked")
    if os.environ.get("JARVIS_ALLOW_LIVE") == "1":
        print("  WARNING: real-money accounts are UNLOCKED.")
    print("  Ctrl+C to stop\n")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        if tunnel:
            tunnel.terminate()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:                                # keep the window open so the error can be read
        print("\nscORPio zilat stopped:", e)
        if getattr(sys, "frozen", False):
            input("Press Enter to close...")
