#!/bin/sh
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt
python3 server.py --lan --share
