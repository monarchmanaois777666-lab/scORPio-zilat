"""
memory.py - Jarvis's long-term memory.

She knows who built her (Monarch Manaois) and greets you by name.
Everything is saved on YOUR server in ~/.jarvis_cache, so it survives restarts and follows you across devices:
  memory.json   who you are (name, how to address you) and the facts you asked her to remember
  journal.jsonl every conversation and every event (trades proposed, manager reports), in order, never trimmed
She loads your name and facts into every AI answer, so she knows you. Say:
  "my name is Amara" / "call me boss"      "remember that I only trade the London session"
  "what do you remember about me"           "what did we talk about today"      "what happened today"
  "repeat that" / "what did you say"        "what was my last question"        "and what about gold?" (a follow-up)
  "forget that I like gold"                 "forget everything" (then "confirm forget everything")
Wiping memory never touches your trade history (that lives in the manager's ledger).
"""
import os, re, json, time
from datetime import datetime, timedelta

DIR = os.path.join(os.path.expanduser("~"), ".jarvis_cache")
# Who she is built by and for. Built in, not erasable by "forget everything". Change in .env: JARVIS_OWNER_NAME, JARVIS_CREATOR.
OWNER = os.environ.get("JARVIS_OWNER_NAME", "Monarch")
CREATOR = os.environ.get("JARVIS_CREATOR", "Monarch Manaois")
TITLES = {"sir", "boss", "madam", "ma'am", "miss", "captain", "chief"}


class Memory:
    def __init__(self, directory=None):
        self.dir = directory or DIR
        self.profile, self.journal = os.path.join(self.dir, "memory.json"), os.path.join(self.dir, "journal.jsonl")
        try:
            self.p = json.load(open(self.profile, encoding="utf-8"))
        except Exception:
            self.p = {}
        self.p["name"] = self.p.get("name") or OWNER
        self.p["address"] = self.p.get("address") or self.p["name"]
        self.p.setdefault("facts", [])
        self.pending_forget = False
        self.last_reply = self.last_user = None          # the current conversation
        self.repeated = False

    # ------------------------------------------------------------ basics
    @property
    def address(self):
        return self.p.get("address") or "boss"

    def _save(self):
        os.makedirs(self.dir, exist_ok=True)
        json.dump(self.p, open(self.profile, "w", encoding="utf-8"), indent=1)

    def log(self, kind, who, text):
        """Append to the journal. kind: 'chat' (a message) or 'event' (something that happened)."""
        os.makedirs(self.dir, exist_ok=True)
        with open(self.journal, "a", encoding="utf-8") as f:
            f.write(json.dumps({"t": time.time(), "kind": kind, "who": who, "text": text[:2000]}, ensure_ascii=False) + "\n")

    def _tail(self, max_bytes=400_000):
        try:
            with open(self.journal, "rb") as f:
                f.seek(0, 2)
                size = f.tell()
                f.seek(max(0, size - max_bytes))
                data = f.read().decode("utf-8", "ignore")
        except OSError:
            return []
        out = []
        for line in data.splitlines():
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
        return out

    def _day(self, rows, day):
        return [r for r in rows if datetime.fromtimestamp(r["t"]).date() == day]

    def _last(self, who):
        """Most recent journal message by 'user' or 'jarvis' (survives a restart)."""
        rows = [r["text"] for r in self._tail(120_000) if r["kind"] == "chat" and r["who"] == who]
        return rows[-1] if rows else None

    def note_exchange(self, q, reply):
        """Called after every turn. Repeats and 'what did I ask' do not overwrite what is being repeated."""
        if not self.repeated:
            self.last_user, self.last_reply = q, reply
        self.repeated = False

    def add_fact(self, text, auto=False):
        text = text.strip().rstrip(".")
        if text and not any(f["text"].lower() == text.lower() for f in self.p["facts"]):
            self.p["facts"].append({"text": text, "t": time.time(), "auto": auto})
            self._save()
            return True
        return False

    # ------------------------------------------------------------ learning
    def observe(self, text):
        """Quietly remember stated preferences ('I prefer...', 'I never trade Fridays') without changing the reply."""
        if text.strip().endswith("?"):
            return
        m = re.match(r"^\s*i\s+(?:really\s+|always\s+|usually\s+)?(prefer|like|love|hate|never|always|only)\b(.{3,160})$", text, re.I)
        if m:
            self.add_fact("The user said: " + text.strip(), auto=True)

    def handle(self, text):
        """Memory commands. Returns Jarvis's reply, or None when the message is not about memory."""
        t, s = text.strip(), text.strip().lower()
        asked, self.pending_forget = self.pending_forget, False
        self.repeated = False
        if asked and re.search(r"confirm forget", s):
            self.wipe()
            return "Done. I have erased everything I remembered about you and our conversations. Your trade history is untouched."
        if re.search(r"\bforget (everything|all)\b|\bwipe (your |my )?memor|\berase (your |my )?memor", s):
            self.pending_forget = True
            return ("This erases everything I remember about you and all our conversations, but not your trade history. "
                    "Say confirm forget everything if you are sure.")
        if re.search(r"\bwho (?:built|made|created|programmed|designed|developed|invented|owns?) (?:you|this)\b|\bwho is your (?:creator|maker|builder|developer|owner|boss|father)\b|\bwho(?:'s| is) your boss\b|\bwho do you work for\b", s):
            return f"I was built by {CREATOR}, my boss. When my AI answers are on, I run on Claude, made by Anthropic."
        if re.search(r"\bwho am i\b|\bwhat(?:'s| is) my (?:full )?name\b|\bdo you know (?:me|who i am)\b|\bdo you remember my name\b", s):
            if self.p["name"] == OWNER:
                return f"You are {CREATOR}, the person who built me, and I am glad to see you."
            return f"You are {self.p['name']}."
        m = re.match(r"^\s*(?:please\s+)?forget\s+(?:that\s+|about\s+|the fact that\s+)?(.+)$", s)
        if m:
            key = m.group(1).strip().rstrip(".")
            keep = [f for f in self.p["facts"] if key not in f["text"].lower()]
            gone = len(self.p["facts"]) - len(keep)
            self.p["facts"] = keep
            self._save()
            return f"Forgotten: {gone} thing{'s' if gone != 1 else ''}." if gone else "I do not have that in my memory."
        m = re.search(r"\b(?:my name is|call me|i am called|i'm called)\s+([A-Za-z][A-Za-z'\-]*)", t, re.I)
        if m:
            word = m.group(1)[0].upper() + m.group(1)[1:].lower()
            if word.lower() in TITLES:
                self.p["address"] = word.lower()
                self._save()
                return f"Of course. I will call you {word.lower()}."
            self.p["name"] = self.p["address"] = word
            self._save()
            return f"Lovely to meet you, {word}. I will remember that."
        m = re.match(r"^\s*(?:please\s+)?remember(?:\s+that)?\s+(.+)$", t, re.I)
        if m:
            self.add_fact(m.group(1))
            return "I will remember that: " + m.group(1).strip().rstrip(".") + "."
        if re.search(r"what do you (?:remember|know) about me|what have you remembered|what do you remember", s):
            return self.describe()
        if re.search(r"\b(?:repeat (?:that|it|what you said|yourself)|say (?:that|it) again|what did you (?:just )?say|come again|pardon|can you repeat|one more time|sorry,? what)\b", s):
            last = self.last_reply or self._last("jarvis")
            self.repeated = True
            return ("Of course. I said: " + last) if last else "I have not said anything yet."
        if re.search(r"what (?:was|is) my (?:last|previous) (?:question|message)|what did i (?:just )?(?:say|ask)(?: (?:before|last|a moment ago|just now))?\s*\??\s*$", s):
            last = self.last_user or self._last("user")
            self.repeated = True
            return ("You asked: " + last) if last else "You have not asked me anything yet."
        day = datetime.now().date() - (timedelta(days=1) if "yesterday" in s else timedelta(0))
        label = "yesterday" if "yesterday" in s else "today"
        if re.search(r"what did (?:i|we) (?:talk about|discuss|ask|say|do) (?:today|yesterday)|what did we (?:talk about|discuss|do)", s):
            asked_ = [r["text"] for r in self._day(self._tail(), day) if r["kind"] == "chat" and r["who"] == "user"][-5:]
            return (f"{label.capitalize()} you asked me: " + "; ".join(a[:80] for a in asked_) + ".") if asked_ else f"We have not talked {label} yet."
        if re.search(r"what (?:happened|did you do|have you done)", s):
            ev = [r["text"] for r in self._day(self._tail(), day) if r["kind"] == "event"][-6:]
            return (f"{label.capitalize()}: " + " ".join(e[:140] for e in ev)) if ev else f"Nothing has been reported {label}."
        return None

    def describe(self):
        bits = []
        if self.p["name"]:
            bits.append(f"your name is {self.p['name']}")
        if self.p["address"] and self.p["address"] != self.p["name"]:
            bits.append(f"you like to be called {self.p['address']}")
        facts = [f["text"] for f in self.p["facts"]]
        if not bits and not facts:
            return "I do not remember anything about you yet. Tell me your name, or say remember that, followed by anything you want me to keep."
        return "I remember that " + ", and ".join(bits + facts[-12:]) + "." if bits else "I remember: " + "; ".join(facts[-12:]) + "."

    # ------------------------------------------------------------ giving memory to the AI
    def context(self):
        """Text added to every AI answer so she knows you."""
        lines = [f"You were built by {CREATOR}, your creator and boss. If asked who built you, say so, and that your AI answers run on Claude from Anthropic.",
                 f"The user's name is {self.p['name']}.", f"Address the user as {self.address}. Never assume the user's gender."]
        for f in self.p["facts"][-25:]:
            lines.append("- " + f["text"])
        recent = [r["text"] for r in self._tail(60_000) if r["kind"] == "event" and time.time() - r["t"] < 86400][-5:]
        if recent:
            lines.append("Recent trading events: " + " | ".join(x[:120] for x in recent))
        return "\n\nYour long-term memory of the user (use it naturally, never recite it):\n" + "\n".join(lines)

    def recent(self, n=12):
        """The last n chat messages as AI history, so a restart does not make her forget the conversation."""
        rows = [r for r in self._tail(200_000) if r["kind"] == "chat"][-n:]
        msgs = [{"role": "user" if r["who"] == "user" else "assistant", "content": r["text"]} for r in rows]
        while msgs and msgs[0]["role"] != "user":
            msgs.pop(0)
        out = []
        for m in msgs:                                    # the API needs strictly alternating roles
            if out and out[-1]["role"] == m["role"]:
                out[-1]["content"] += " " + m["content"]
            else:
                out.append(dict(m))
        return out

    def wipe(self):
        for p in (self.profile, self.journal):
            try:
                os.remove(p)
            except OSError:
                pass
        self.p = {"name": OWNER, "address": OWNER, "facts": []}
        self.pending_forget = False
