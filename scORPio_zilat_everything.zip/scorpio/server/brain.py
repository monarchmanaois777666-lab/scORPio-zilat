"""brain.py - forex knowledge + optional Claude answers (no GUI dependencies)."""
import os, sys, json, re, datetime, urllib.request

def _load_env():
    """Read KEY=VALUE lines from a .env file next to this script."""
    base = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(base, ".env")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip("\"'"))

_load_env()

# ------------------------------------------------------------------ brain
FOREX_KB = [
    (r"\b(boy or girl|are you (a )?(man|woman|girl|boy|male|female)|your gender|she or he)\b", "I am an AI, and I present as a woman: my voice and the way I speak are always female."),
    ('\\bgold\\b|xauusd|xau.?usd', 'Gold, XAUUSD, is priced in dollars per ounce. It moves in much bigger swings than a currency pair and the spread is wider, so I assume a higher cost and size the position by dollars per ounce. On MetaTrader 5 one standard lot is 100 ounces. I can scan and trade it when you ask, for example scan XAUUSD, and I backtest it like any other pair before proposing a trade. Gold is not in my default scan unless you set JARVIS_INCLUDE_GOLD to 1. Expect larger losses per move, so keep your risk low.'),
    ('4 ?h(our)? range|four.?hour range|first 4 ?h(our)? candle|failed breakout', 'The four hour range strategy: on the four-hour chart, wait for the first New York candle of the day to close, and mark its high and low. Then on the five-minute chart, wait for a candle to close outside the range, and the very next candle to close back inside. If it broke above and came back, go short. If it broke below and came back, go long. Put the stop beyond the extreme of the failed breakout, and take profit at the opposite side of the range, or at one to two risk to reward. Ask me to scan after the first four-hour candle closes and I will test it before proposing a trade.'),
    (r'cr model|9 ?am|8 ?am (candle|high|low|range)|ifvg|inverse fair value', "The nine A M C R model: mark the high and low of the eight A M one-hour candle in New York time. If the nine o'clock candle trades into the high, bias is short toward the low. If it trades into the low, bias is long toward the high. Then on the one-minute chart, wait for an inverse fair value gap and an order block while price taps that level, enter on confirmation, put the stop beyond the swing, and target the other side of the eight A M range. Ask me to scan between nine and noon New York time and I will test it before proposing a trade."),
    ('multi.?time.?frame|higher time.?frame|top.?down', 'Top-down analysis: mark the trend and key levels on a higher timeframe like the daily or four-hour, refine your zone on the one-hour, then time entries on the fifteen-minute or five-minute. Only trade in the direction of the higher timeframe bias.'),
    ('\\bpips?\\b|\\blot size|\\blots?\\b|pip value', 'A pip is the fourth decimal place on most pairs, and the second on yen pairs. A standard lot is 100,000 units, worth about ten dollars per pip on dollar-quoted pairs, a mini lot is a tenth of that, and a micro lot a hundredth.'),
    ('leverage|margin', 'Leverage lets you control a large position with small capital, for example one to fifty. Margin is the deposit your broker holds. High leverage magnifies losses as much as gains, so most professionals keep effective leverage low and risk a fixed percent per trade.'),
    ('position siz|how much (to )?risk|risk management|risk per trade|money management', 'Risk one to two percent of your account per trade. Position size equals account risk in dollars divided by stop distance in pips times pip value. Aim for at least one to two reward-to-risk, and cap your daily loss so one bad day cannot wreck you.'),
    ('risk.?reward|reward.?to.?risk|\\brr\\b|win rate', 'Expectancy equals win rate times average win minus loss rate times average loss. With one to two risk-reward you only need to win about thirty-four percent of trades to break even, before costs. Win rate alone means nothing without the reward-to-risk ratio.'),
    ('stop.?loss|\\bsl\\b|take profit|trailing', 'Place your stop where your idea is proven wrong, such as beyond a swing high or low or a multiple of ATR, not at a random pip count. Take profit at the next structure level or a fixed multiple of risk, and trail stops behind swing points or the ATR once price moves in your favor.'),
    ('support|resistance|supply.?(and)?.?demand|demand zone|supply zone', 'Support and resistance are price areas where buyers or sellers repeatedly stepped in. Treat them as zones, not exact lines. A level that breaks often flips role, so old resistance becomes new support. Supply and demand zones mark the origin of strong impulsive moves.'),
    ('trend ?line|channel', 'Draw a trendline through at least two swing lows in an uptrend or two swing highs in a downtrend, and it gains weight with a third touch. A break with a retest often signals a change of trend, and parallel channels give you buy-the-dip and sell-the-rally zones.'),
    ('candle|pin bar|engulf|doji|hammer|shooting star|price action|inside bar', 'Key price action signals: pin bars, which show rejection with a long wick, engulfing candles, which show momentum shifts, doji for indecision, and inside bars for compression before a breakout. They matter most at key levels, with the trend, and on higher timeframes.'),
    ('golden cross|death cross|moving average|\\bsma\\b|\\bema\\b|\\bma\\b', 'Moving averages smooth price and define trend. The fifty and two-hundred averages are popular, a golden cross is the fifty crossing above the two hundred, and a death cross is the reverse. EMAs react faster than SMAs. They lag, so they work best in trends and badly in ranges.'),
    ('\\brsi\\b|relative strength', 'RSI is a momentum oscillator from zero to one hundred, using fourteen periods by default. Above seventy is overbought and below thirty is oversold, but in strong trends it can stay extreme for a long time. Divergence between RSI and price is a more useful warning than the levels alone.'),
    ('macd', 'MACD is the twelve-period EMA minus the twenty-six-period EMA, with a nine-period signal line and a histogram. A signal line cross or zero-line cross shows momentum shifts, and divergence against price warns of exhaustion. It lags, so use it with structure.'),
    ('bollinger|bands', 'Bollinger Bands are a twenty-period average with bands two standard deviations away. A squeeze signals low volatility before expansion, and walking the band shows strong trend. In ranges, touches of the band can mean revert to the mean.'),
    ('stochastic', 'The stochastic oscillator compares the close to the recent high-low range. Readings above eighty are overbought and below twenty are oversold. It works best in ranging markets, and crosses are stronger when they occur at key support or resistance.'),
    ('\\batr\\b|average true range|volatility', 'ATR measures average price range over fourteen periods. Use it to set stops, for example one and a half to two times ATR from entry, to size positions, and to see whether the market is quiet or expanding.'),
    ('fib|retracement|golden ratio|extension', 'Fibonacci retracements map likely pullback depths in a trend, most watched at thirty-eight, fifty and sixty-two percent, with the sixty-one point eight percent golden ratio. Extensions at one-twenty-seven and one-sixty-one are used for targets. They work best when they line up with other structure.'),
    ('ichimoku|cloud|kumo', 'Ichimoku shows trend, momentum and support all at once. Price above the cloud is bullish and below is bearish, a thick cloud means strong support or resistance, and the Tenkan crossing the Kijun gives timing signals. The lagging span confirms the trend.'),
    ('\\badx\\b|trend strength|directional', 'ADX measures trend strength, not direction. Below twenty usually means a range, above twenty-five suggests a trend. Use it to choose strategy: trend following when high, mean reversion when low.'),
    ('pivot', "Pivot points are calculated from the prior period's high, low and close, giving a central pivot with support and resistance levels. Intraday traders watch them as reaction zones, especially on the London and New York sessions."),
    ('diverg', 'Divergence is when price makes a new high or low but an oscillator like RSI or MACD does not. Regular divergence warns of a possible reversal, hidden divergence suggests trend continuation. Never trade it alone; wait for structure to confirm.'),
    ('break.?out|false break|fakeout|retest', 'Breakout trading enters when price closes beyond a key level on strong momentum or volume. Many breaks fail, so traders wait for a candle close and a retest of the broken level. A failed breakout that snaps back is itself a strong reversal signal.'),
    ('trend.?follow|trend trading|with the trend|higher highs|market structure|\\bbos\\b|choch|break of structure', 'An uptrend is a series of higher highs and higher lows, and a downtrend is the opposite. Trend followers buy pullbacks to support, moving averages or Fibonacci levels. A break of structure confirms the trend continues, and a change of character warns it may reverse.'),
    ('range|mean.?reversion|sideways|consolidat', 'In a range, buy near support and sell near resistance, with stops just outside the range. Oscillators like RSI and stochastic work better there. Always expect an eventual breakout, so reduce size near the edges.'),
    ('scalp|day trad|swing|position trad|trading style', "Scalping holds for seconds to minutes and needs tight spreads and discipline. Day trading closes by day's end. Swing trading holds days to weeks and suits people with jobs. Position trading holds weeks to months and follows macro trends. Pick the style that fits your schedule and temperament."),
    ('carry trade|interest rate|central bank|rate differential|swap', 'A carry trade buys a high-yield currency against a low-yield one to earn the interest difference. It works while risk appetite is calm, and unwinds violently in risk-off panics. Central bank rate expectations are the biggest long-term driver of currencies.'),
    ('news|nfp|non.?farm|cpi|inflation|fomc|fed\\b|ecb|boe|boj|fundamental', 'Big movers are central bank decisions like the Fed, ECB, BoE and BoJ, non-farm payrolls, CPI inflation, GDP and employment data. Spreads widen and price whipsaws around releases, so many traders stand aside or wait for the first reaction to settle.'),
    ('session|london|new york|tokyo|asian|overlap|best time', 'The Asian session is quieter and often ranges, London brings the highest liquidity and real trends, and New York adds volatility, especially during the London overlap from about eight to noon Eastern. The overlap is usually the best time to trade.'),
    ('major|pairs|eurusd|gbpusd|usdjpy|audusd|usdchf|usdcad|nzdusd|cross pair|exotic', 'The majors are EURUSD, GBPUSD, USDJPY, USDCHF, AUDUSD, USDCAD and NZDUSD, with the tightest spreads. Crosses like EURJPY skip the dollar, and exotics pair a major with an emerging currency and cost more to trade. GBP pairs are volatile, JPY pairs are often risk-sentiment driven.'),
    ('correlat|dxy|dollar index|safe haven', 'Many pairs move together: EURUSD and GBPUSD are positively correlated, EURUSD and USDCHF negatively. The dollar index DXY tracks dollar strength against a basket. Do not stack several trades that are really the same bet on the dollar.'),
    ('smart money|ict|order block|liquidity|fair value gap|\\bfvg\\b|stop hunt|inducement', 'Smart money concepts assume large players hunt liquidity, meaning stops resting above highs and below lows, before reversing. Traders look for a liquidity sweep, a change of character, then an entry at an order block or fair value gap. It is popular but subjective, so backtest it before trusting it.'),
    ('psycholog|emotion|discipline|revenge|fomo|overtrad|fear|greed', 'Most failure comes from psychology, not strategy: revenge trading, FOMO, moving stops, overtrading and oversizing. Have written rules, a fixed risk per trade, a daily loss limit, and take breaks after losses. Consistency beats brilliance.'),
    ('backtest|journal|demo|paper trad|forward test', 'Backtest your strategy over at least a hundred trades across different market conditions, then forward test on a demo account before going live. Keep a journal with the setup, entry, exit, reason, screenshot and emotion. Review it weekly and fix the leaks.'),
    ('spread|commission|slippage|broker|ecn|market maker', 'Costs are spread, commission and slippage. Choose a regulated broker with tight spreads, and remember scalping strategies are the most cost-sensitive. Avoid trading right at news or rollover when spreads blow out.'),
    ('strateg|how (do i|to) trade forex|best (indicator|strategy)|setup|system', 'A solid beginner framework: identify the daily trend, wait for a pullback to a support zone or key moving average, enter on a confirming candle such as an engulfing or pin bar, put the stop beyond structure, and target at least one to two. Add one or two indicators at most, and always trade with a strict risk limit.'),
    ('forex|fx\\b|currency (trading|market)|what is trading|learn trading', 'Forex is the global currency market, trading about seven trillion dollars a day, open twenty-four hours from Monday to Friday. You buy one currency while selling another, so every trade is a pair. Profit comes from price moves, and risk control matters more than any indicator.'),
    ('(current|today|right now|latest|live|now).*(trend|price|market|forecast|rate|signal)|will .* (go up|go down|rise|fall)|buy or sell|prediction|predict', 'I have no live price feed here, and nobody can predict the market reliably. What I can do is give you the method: check the daily trend structure, key levels, the upcoming news calendar, and whether price is above or below the fifty and two-hundred averages, and I will help you interpret what you see.'),
]

SYSTEM = ("You are scORPio zilat, a Jarvis-style, witty, calm, British-sounding AI assistant who is a woman: always speak and write as a woman, warm and confident, and never describe yourself as male. You are also an expert "
          "forex trading mentor. You know currency pairs, sessions, fundamentals and central banks, price action, "
          "market structure, support and resistance, supply and demand, smart money concepts, candlestick patterns, "
          "every major indicator (moving averages, RSI, MACD, Bollinger, stochastic, ATR, ADX, Fibonacci, Ichimoku, pivots), "
          "trend following, breakout, range, scalping, swing and carry strategies, risk management, position sizing, "
          "backtesting and trading psychology. You have no live market data, so never invent current prices or forecasts; "
          "explain how to analyse instead. Be honest that no strategy is guaranteed and trading is risky, and mention "
          "once in a while that this is education, not financial advice. "
          "Your replies are spoken aloud: answer in two to four short sentences, plain text only, "
          "no markdown, lists or emojis. Address the user by name when your memory notes give it, otherwise as 'boss'; never assume the user's gender.")
HISTORY = []

memory_context = lambda: ""        # the server plugs Jarvis's long-term memory in here


def personalize(text: str, address: str = "boss") -> str:
    """Replace the stock 'sir' with how this user wants to be addressed (their name, or 'boss')."""
    address = address or "boss"
    return re.sub(r"\bsir\b", lambda m: address[0].upper() + address[1:] if m.group(0)[0].isupper() else address, text, flags=re.I)


def llm_ask(q: str):
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        return None
    body = json.dumps({"model": os.environ.get("JARVIS_MODEL", "claude-sonnet-5-5"),
                       "max_tokens": 400, "system": SYSTEM + memory_context(), "messages": HISTORY[-24:] + [{"role": "user", "content": q}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", body, {
        "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            text = "".join(b.get("text", "") for b in json.load(r)["content"]).strip()
        return text or None
    except Exception as e:
        print("LLM error:", e)
        return None

def llm_once(system: str, user: str, max_tokens: int = 300):
    """Single question to Claude with no chat history (used by the manager's briefing). None if no key."""
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        return None
    body = json.dumps({"model": os.environ.get("JARVIS_MODEL", "claude-sonnet-5-5"), "max_tokens": max_tokens,
                       "system": system, "messages": [{"role": "user", "content": user}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", body, {
        "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return "".join(b.get("text", "") for b in json.load(r)["content"]).strip() or None
    except Exception as e:
        print("LLM error:", e)
        return None

def ask(q: str) -> str:
    return llm_ask(q) or local_ask(q)

def local_ask(q: str) -> str:
    """Offline fallback rules."""
    s = q.lower()
    for pat, ans in FOREX_KB:
        if re.search(pat, s):
            return ans + " This is education, not financial advice."
    m = re.search(r"(\d+(?:\.\d+)?)\s*([+\-*x/])\s*(\d+(?:\.\d+)?)", s)
    if m:
        a, o, b = float(m[1]), m[2], float(m[3])
        r = a + b if o == "+" else a - b if o == "-" else a / b if o == "/" and b else a * b
        return f"That comes to {round(r, 4):g}."
    if re.search(r"\b(hi|hello|hey)\b", s):
        return "Good to see you, sir. All systems are online."
    if "time" in s:
        return "It is " + datetime.datetime.now().strftime("%I:%M %p").lstrip("0") + "."
    if re.search(r"\b(date|day|today)\b", s):
        return "Today is " + datetime.datetime.now().strftime("%A, %B %d") + "."
    if re.search(r"who are you|your name|what are you", s):
        return "I am scORPio zilat, your Jarvis-style AI trading assistant."
    if "joke" in s:
        return "I would tell you a UDP joke, but you might not get it."
    if re.search(r"code|codebase|built|made", s):
        return "Scanning my own source now. Particles, trigonometry, and a lot of style."
    if "thank" in s:
        return "Always a pleasure, sir."
    return ("I do not have a built-in answer for that. Add an Anthropic key to my server and I can answer anything and follow the whole conversation. "
            "I have saved your question, so you can ask me again later.")

