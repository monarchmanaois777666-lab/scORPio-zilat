The web assets in `www/` are copied from `server/app/` by the build workflow. Do not edit them here.
