# scORPio zilat

A Jarvis-style AI forex assistant built by **Monarch Manaois**. She speaks in a female voice, welcomes you by name, remembers your conversations,
scans the market with seven strategies behind a strict profit test, and trades only with your approval (or on authorised autopilot).
A manager (and up to 8 read-only workers) does the scanning for Jarvis, the boss.

## What is in this repository
| Folder / file | What it is |
|---|---|
| `docs/` | The **web app**: 6 files, no server needed. GitHub Pages serves it as your own link. |
| `server/` | The **trading server**: Jarvis, the manager and workers, memory, guards, OANDA and Exness/MT5 brokers. Has its own `README.md` (read it) |
| `server/docs/` | Visual strategy guides: the 9 AM CR model and the 4 Hour Range strategy |
| `mobile/` | The Android and iPhone app project (Capacitor) |
| `.github/workflows/build.yml` | Builds the Android APK, the unsigned iPhone .ipa, and the Windows server .exe in GitHub's cloud |
| `BUILD-WORKFLOW.yml` | A copy of that workflow, for the manual step below |

## 1. Put it on GitHub
1. Unzip this file first. GitHub's website cannot unpack a zip for you.
2. github.com > **New repository** (name it `scorpio`). Choose **Public** if you want a free web app link (Pages on a private repository needs a paid plan).
   Nothing in here is secret: your keys only ever go in a `.env` file on your own computer, and `.gitignore` keeps it out.
3. **Add file > Upload files** and drag in **the contents of the unzipped folder**: `docs`, `server`, `mobile`, `README.md`, `BUILD-WORKFLOW.yml`, `.gitignore`.
   (Browsers often skip hidden folders such as `.github`, so do step 4 as well.) No computer? Upload the six files inside `docs/` from your phone, which is all the web app needs.
4. **Add file > Create new file**, name it exactly `.github/workflows/build.yml`, paste in the contents of `BUILD-WORKFLOW.yml`, and commit.

## 2. The web app (a live link in about a minute)
**Settings > Pages > Source: Deploy from a branch > Branch `main`, folder `/docs` > Save.**
Your link will be `https://YOUR-USERNAME.github.io/scorpio/`. Open it on your phone and use Add to Home Screen.
Tap the gear to add your Anthropic API key for AI answers (it stays on that phone). The chart button opens TradingView's live charts and scanner.
Details: `docs/DEPLOY-WEB-APP.txt`.

## 3. The phone apps and the Windows server
**Actions > Build apps > Run workflow.** When the three jobs finish, download from the run's *Artifacts*:
`app-debug.apk` (Android), `scORPio-zilat-unsigned.ipa` (iPhone, signed with AltStore or Sideloadly), and `scORPio-zilat-server.exe` (Windows).
The workflow is untested, so if a step turns red, copy the error from the log. For the iPhone and store details, see `server/README.md` and the notes below.

## 4. The trading server (needed for live prices, scanning, trading)
Read `server/README.md`. In short: copy `server/.env.example` to `server/.env`, add your broker keys (start with a **practice or demo account**), and run
`server/run_windows.bat` (or `run_mac_linux.sh`). It prints your app link. Exness needs Windows with MetaTrader 5; OANDA works anywhere.

## Honest notes
- Tested on simulated data and logic checks, **not against a live broker, real phones, or the app stores**. Run on a practice account for weeks first.
- A good backtest does not predict profit, and no setting makes her win every trade. This is educational software, not financial advice; forex trading carries a high risk of loss.
- Putting a trading app on the App Store or Google Play is restricted for individuals (Apple expects finance apps from the licensed institution; Google needs a financial-features declaration). Install privately instead (TestFlight, Play internal testing, the APK, or the web app).
- Never commit `.env`, API keys or tokens. If one is ever uploaded by mistake, revoke it and make a new one.
